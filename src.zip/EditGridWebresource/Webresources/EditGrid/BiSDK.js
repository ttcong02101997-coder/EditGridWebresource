/**
 * BiSDK - Common JavaScript SDK
 * Author: CongTT
 */
"use strict";
const DOC = top.document;
const _extensionSDK = {
    _styleId: "modal-sdk-style",
    _metadataCache: new Map(),
    _requiredFieldsCache: new Map(),
    _init() {
        if (DOC.getElementById(this._styleId))
            return;

        const style = DOC.createElement("style");
        style.id = this._styleId;
        style.textContent = `
                    .modal-overlay{
                        position:fixed;
                        inset:0;
                        z-index:999999;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        padding:10px;
                        background:rgba(15,23,42,.55);
                        backdrop-filter:blur(10px);
                        opacity:0;
                        visibility:hidden;
                        transition:all .25s ease;
                    }

                    .modal-overlay.show{
                        opacity:1;
                        visibility:visible;
                    }

                    .modal-dialog{
                        width:var(--modal-width);
                        height:var(--modal-height);
                        // max-width:95vw;
                        // max-height:90vh;
                        display:flex;
                        flex-direction:column;
                        background:#ffffff;
                        border-radius:15px;
                        overflow:hidden;
                        border:1px solid #e5e7eb;
                        box-shadow: 0 10px 15px -3px rgba(0,0,0,.1), 0 20px 40px rgba(0,0,0,.15);
                        opacity:0;
                        transform: translateY(25px) scale(.98);
                        transition: all .25s cubic-bezier(.22,1,.36,1);
                    }

                    .modal-overlay.show .modal-dialog{
                        opacity:1;
                        transform: translateY(0) scale(1);
                    }

                    .modal-header{
                        height:50px;
                        flex-shrink:0;
                        display:flex;
                        align-items:center;
                        justify-content:space-between;
                        padding:0 10px;
                        border-bottom: 1px solid #f1f5f9;
                        background:#fff;
                    }

                    .modal-title{
                        font-size:18px;
                        font-weight:600;
                        color:#0f172a;
                    }

                    .modal-close{
                        width:36px;
                        height:36px;
                        border:none;
                        outline:none;
                        background:transparent;
                        border-radius:10px;
                        cursor:pointer;
                        transition:.2s;
                    }

                    .modal-close:hover{
                        background:#f1f5f9;
                    }

                    .modal-body{
                        flex:1;
                        overflow:auto;
                        padding:10px;
                        background:#fff;
                    }

                    .modal-footer{
                        flex-shrink:0;
                        padding:16px 24px;
                        display:flex;
                        justify-content:flex-end;
                        gap:12px;
                        border-top: 1px solid #f1f5f9;
                        background:#fff;
                    }

                    .modal-btn{
                        height:40px;
                        padding:0 16px;
                        border:none;
                        border-radius:10px;
                        cursor:pointer;
                        font-size:14px;
                        font-weight:500;
                        transition:.2s;
                    }

                    .modal-btn:hover{
                        transform:translateY(-1px);
                    }

                    .modal-btn-secondary{
                        background:#f1f5f9;
                        color:#334155;
                    }

                    .modal-btn-primary{
                        background:#2563eb;
                        color:white;
                    }

                    .modal-btn-primary:hover{
                        background:#1d4ed8;
                    }

                    .modal-input{
                        width:100%;
                        height:42px;
                        padding:0 12px;
                        border:1px solid #d1d5db;
                        border-radius:10px;
                        outline:none;
                    }

                    .modal-input:focus{
                        border-color:#2563eb;
                        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
                    }
                `;
        DOC.head.appendChild(style);
    },

    CONTAINER_ID: "mysdk-form-notification-container",
    getContainer() {
        let container = DOC.getElementById(this.CONTAINER_ID);
        if (container) {
            return container;
        }

        container = DOC.createElement("div");
        container.id = this.CONTAINER_ID;
        container.style.cssText = `
                width:100%;
                margin-bottom:10px;
                box-sizing:border-box;
            `;
        const targets = [
            DOC.querySelector("[data-id='form-container']"),
            DOC.querySelector("[role='main']"),
            DOC.querySelector("#appRoot"),
            DOC.body
        ];
        const target = targets.find(x => x);
        target.prepend(container);
        return container;
    },

    getConfig(type) {
        const configs = {
            info: {
                bg: "#deecf9",
                border: "#0078d4",
                icon: "ℹ️"
            },
            warning: {
                bg: "#fff4ce",
                border: "#ffb900",
                icon: "⚠️"
            },
            error: {
                bg: "#fde7e9",
                border: "#d13438",
                icon: "❌"
            },
            success: {
                bg: "#dff6dd",
                border: "#107c10",
                icon: "✅"
            }
        };

        return configs[type] || configs.WARNING;
    },

    CreateXml(fetchXml, pagingCookie, page) {
        var domParser = new DOMParser();
        var xmlSerializer = new XMLSerializer();
        var fetchXmlDocument = domParser.parseFromString(fetchXml, "text/xml");

        if (page) {
            fetchXmlDocument
                .getElementsByTagName("fetch")[0]
                .setAttribute("page", page.toString());
        }

        if (pagingCookie) {
            var cookieDoc = domParser.parseFromString(pagingCookie, "text/xml");
            var innerPagingCookie = domParser.parseFromString(
                decodeURIComponent(
                    decodeURIComponent(
                        cookieDoc
                            .getElementsByTagName("cookie")[0]
                            .getAttribute("pagingcookie")
                    )
                ),
                "text/xml"
            );
            fetchXmlDocument
                .getElementsByTagName("fetch")[0]
                .setAttribute(
                    "paging-cookie",
                    xmlSerializer.serializeToString(innerPagingCookie)
                );
        }

        return xmlSerializer.serializeToString(fetchXmlDocument);
    },

    retrievePage(entityName, fetchXml, pageNumber, pagingCookie) {
        var fetchXml = "?fetchXml=" + this.CreateXml(fetchXml, pagingCookie, pageNumber);
        return top.Xrm.WebApi.retrieveMultipleRecords(entityName, fetchXml).then(
            function success(result) {
                return result;
            },
            function error(e) {
                throw e;
            }
        );
    },

    renderButton: async function ({ entityName, buttonName, tooltip, index, visibleButton = async () => true, onClick = async () => { }, more = true } = {}) {
        const isVisible = await visibleButton();
        if (!isVisible) {
            return;
        }

        const commandBar = DOC.querySelector(`[data-id="CommandBar"][data-lp-id="commandbar-Form:${entityName}"]`);
        let sourceButtonId = commandBar.childNodes[1].id;
        let source = DOC.getElementById(sourceButtonId);
        // if (more) {
        //     source = commandBar.querySelector("button")?.closest("[id]");
        // }

        if (!source) {
            console.error("Source button not found:", sourceButtonId);
            return null;
        }

        const newItem = source.cloneNode(true);
        const uniqueId = `custom-${Date.now()}`;
        newItem.id = uniqueId;
        const button = newItem.querySelector("button");

        if (button) {
            button.setAttribute("aria-label", tooltip);
            button.setAttribute("title", tooltip);
            button.addEventListener("click", async (e) => {
                e.preventDefault();
                e.stopPropagation();
                await onClick(e);
            });
        }

        const textSpan = [...newItem.querySelectorAll("span")].find(el =>
            el.children.length === 0 && (el.textContent.trim() === "Save & Close" || el.textContent.trim() === "Save")
        );

        if (textSpan) {
            textSpan.textContent = buttonName;
        }

        const desc = newItem.querySelector('span[id^="id-"]');
        if (desc) {
            desc.textContent = tooltip;
            desc.id = `id-${Date.now()}`;
        }

        const img = newItem.querySelector("img");
        if (img) {
            img.src = "https://content.powerapps.com/resource/uci-infra-web/resources/images/Puzzle.7ecc6b0acfa78dd6d589bbf95543ccbc.svg";
            img.alt = buttonName;
            img.title = buttonName;
        }

        if (!more) {
            const parent = source.parentElement;
            if (parent.children[index]) {
                parent.insertBefore(newItem, parent.children[index]);
            }
            else {
                parent.appendChild(newItem);
            }
        }

        return newItem;
    },

    addFilterFetchXML: function (fetchXmlString, searchTerm, fileName) {
        var parser = new DOMParser();
        var xmlDoc = parser.parseFromString(fetchXmlString, "text/xml");

        var filterNode = xmlDoc.getElementsByTagName("filter")[0];

        if (filterNode) {
            var newCondition = xmlDoc.createElement("condition");
            newCondition.setAttribute("attribute", fileName);
            newCondition.setAttribute("operator", "like");
            newCondition.setAttribute("value", `%${searchTerm}%`);
            filterNode.appendChild(newCondition);
        }

        var serializer = new XMLSerializer();
        var modifiedFetchXml = serializer.serializeToString(xmlDoc);

        return modifiedFetchXml;
    },

    renderListLookup: async function (keyword = "", fetchXml, dropdown, element, entityName) {
        const rs = await top.Xrm.Utility.getEntityMetadata(entityName);
        const fieldName = rs.PrimaryNameAttribute;
        if (keyword) fetchXml = this.addFilterFetchXML(fetchXml, keyword, fieldName);
        const result = await top.Xrm.WebApi.retrieveMultipleRecords(entityName, `?fetchXml=${encodeURIComponent(fetchXml)}`);
        dropdown.innerHTML = "";
        result.entities.forEach(item => {
            const div = DOC.createElement("div");
            div.className = "dropdown-item-custom";
            div.style.padding = "10px 12px";
            div.style.cursor = "pointer";
            div.textContent = item[fieldName];

            div.addEventListener("mouseenter", () => {
                div.style.backgroundColor = "#f8f9fa";
            });

            div.addEventListener("mouseleave", () => {
                div.style.backgroundColor = "";
            });

            div.onclick = () => {
                const input = element.parentElement.querySelector("input");
                input.value = item[`${entityName}id`];
                const divLabel = element.parentElement.querySelector("div");
                divLabel.querySelector("div").textContent = item[fieldName];
                divLabel.querySelector("div").title = item[fieldName];
                divLabel.querySelector("div").onclick = () => _extensionSDK.openViewRecord(entityName, item[`${entityName}id`], this);
                divLabel.style.display = "inline-flex";

                input.dispatchEvent(
                    new Event("change", {
                        bubbles: true
                    })
                );
                div.parentElement.parentElement.parentElement.parentElement.parentElement.remove("show");
            };

            dropdown.appendChild(div);
        });
        BiSDK.UI.Loading.global.hide();
    },

    openLookup: async function (entityName, element) {
        const rs = await top.Xrm.Utility.getEntityMetadata(entityName);
        const fieldName = rs.PrimaryNameAttribute;
        var fetchXml = [
            "<fetch top='500'>",
            `  <entity name='${entityName}'>`,
            `    <attribute name='${entityName}id'/>`,
            `    <attribute name='${fieldName}'/>`,
            "    <filter>",
            "      <condition attribute='statecode' operator='eq' value='0'/>",
            "    </filter>",
            "  </entity>",
            "</fetch>"
        ].join("");
        let html = `
            <div class="lookup" style="width: 100%;position: relative;">
                <input id="searchBox-${entityName}" type="text" placeholder="Search ..." 
                style="min-height: calc(1.5em + (.5rem + 2px));
                        padding: .25rem .5rem;
                        font-size: .875rem;
                        border-radius: 4px;
                        border: 1px solid #ced4da;
                        display: block;
                        width: 96.5%;
                        font-weight: 400;
                        line-height: 1.5;
                        color: #212529;
                        background-color: #fff;
                        background-clip: padding-box;
                        -webkit-appearance: none;
                        -moz-appearance: none;
                        appearance: none;
                        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;"
                />
                <div id="dropdown-${entityName}" class="dropdown-list" 
                    style="position: absolute;
                        top: 100%;
                        left: 0;
                        right: 0;
                        background: white;
                        border: 1px solid #dee2e6;
                        border-top: none;
                        border-radius: 0 0 .375rem .375rem;
                        max-height: 220px;
                        overflow-y: auto;
                        display: block;
                        z-index: 1000;"
                    ></div>
            </div>`;

        BiSDK.UI.Modal.show({
            title: "Select Record",
            width: 500,
            height: 330,
            content: html,
            footer: "<div></div>",
            closeOnBackdrop: false
        }).loadingModal();

        setTimeout(() => {
            const input = DOC.getElementById(`searchBox-${entityName}`);
            const dropdown = DOC.getElementById(`dropdown-${entityName}`);

            _extensionSDK.renderListLookup("", fetchXml, dropdown, element, entityName);

            input.addEventListener("input", e => {
                _extensionSDK.renderListLookup(e.target.value, fetchXml, dropdown, element, entityName);
            });
        }, 500);
    },

    renderListLookupFetchXml: async function (keyword = "", fetchXml, dropdown, element, entityName) {
        if (keyword == "" && !top["dataLookup"]) {
            const result = await top.Xrm.WebApi.retrieveMultipleRecords(entityName, `?fetchXml=${encodeURIComponent(fetchXml)}`);
            top["dataLookup"] = result.entities;
        }
        const rs = await top.Xrm.Utility.getEntityMetadata(entityName);
        const fieldName = rs.PrimaryNameAttribute;
        const filtered = top["dataLookup"].filter(x =>
            x[fieldName].toLowerCase().includes(keyword.toLowerCase())
        );
        dropdown.innerHTML = "";
        filtered.forEach(item => {
            const div = DOC.createElement("div");
            div.className = "dropdown-item-custom";
            div.style.padding = "10px 12px";
            div.style.cursor = "pointer";
            div.textContent = item[fieldName];

            div.addEventListener("mouseenter", () => {
                div.style.backgroundColor = "#f8f9fa";
            });

            div.addEventListener("mouseleave", () => {
                div.style.backgroundColor = "";
            });

            div.onclick = () => {
                const input = element.parentElement.querySelector("input");
                input.value = item[`${entityName}id`];
                const divLabel = element.parentElement.querySelector("div");
                divLabel.querySelector("div").textContent = item[fieldName];
                divLabel.querySelector("div").title = item[fieldName];
                divLabel.querySelector("div").onclick = () => _extensionSDK.openViewRecord(entityName, item[`${entityName}id`], this);
                divLabel.style.display = "inline-flex";

                input.dispatchEvent(
                    new Event("change", {
                        bubbles: true
                    })
                );
                div.parentElement.parentElement.parentElement.parentElement.parentElement.remove("show");
            };

            dropdown.appendChild(div);
        });
        BiSDK.UI.Loading.global.hide();
    },

    openLookupFetchXml: async function (fetchXml, entityName, element) {
        delete top["dataLookup"];
        let html = `
            <div class="lookup" style="width: 100%;position: relative;">
                <input id="searchBox-${entityName}" type="text" placeholder="Search ..." 
                style="min-height: calc(1.5em + (.5rem + 2px));
                        padding: .25rem .5rem;
                        font-size: .875rem;
                        border-radius: 4px;
                        border: 1px solid #ced4da;
                        display: block;
                        width: 96.5%;
                        font-weight: 400;
                        line-height: 1.5;
                        color: #212529;
                        background-color: #fff;
                        background-clip: padding-box;
                        -webkit-appearance: none;
                        -moz-appearance: none;
                        appearance: none;
                        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;"
                />
                <div id="dropdown-${entityName}" class="dropdown-list" 
                style="position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background: white;
                    border: 1px solid #dee2e6;
                    border-top: none;
                    border-radius: 0 0 .375rem .375rem;
                    max-height: 220px;
                    overflow-y: auto;
                    display: block;
                    z-index: 1000;"
                ></div>
            </div>`;

        BiSDK.UI.Modal.show({
            title: "Select Record",
            width: 500,
            height: 330,
            content: html,
            footer: "<div></div>",
            closeOnBackdrop: false
        }).loadingModal();

        setTimeout(() => {
            const input = DOC.getElementById(`searchBox-${entityName}`);
            const dropdown = DOC.getElementById(`dropdown-${entityName}`);

            _extensionSDK.renderListLookupFetchXml("", fetchXml, dropdown, element, entityName);

            input.addEventListener("input", e => {
                _extensionSDK.renderListLookupFetchXml(e.target.value, fetchXml, dropdown, element, entityName);
            });
        }, 500);
    },

    removeDataLookup: function (element) {
        element.parentElement.querySelector("div").textContent = "";
        element.parentElement.parentElement.querySelector("input").value = "";
        element.parentElement.style.display = "none";
    },

    openViewRecord: function (entityName, id, element) {
        if (id == undefined || id == "undefined" || id == null || !id)
            id = element.parentElement.parentElement.querySelector("input").value;
        const url = top.Xrm.Utility.getGlobalContext().getClientUrl() + `/main.aspx?etn=${entityName}&pagetype=entityrecord&id=${id}`;
        window.open(url, "_blank");
    },

    getMetadataField: function (entityName, fieldLogicalName) {
        const cacheKey = `${entityName}:${fieldLogicalName}`;
        const cached = this._metadataCache.get(cacheKey);
        if (cached) return cached;

        const request = top.Xrm.Utility.getEntityMetadata(entityName, [fieldLogicalName])
            .then(metadata => metadata.Attributes.get(fieldLogicalName))
            .catch(error => {
                this._metadataCache.delete(cacheKey);
                throw error;
            });

        this._metadataCache.set(cacheKey, request);
        return request;
    },

    getOptionsField: function (attribute) {
        let options = null;
        if (attribute.LogicalName == "statuscode") {
            options = attribute.attributeDescriptor.OptionSet.filter(o => o.State == 0).map((o) => ({
                value: o.Value,
                text: o.Label
            }));
        }
        else {
            options = Object.keys(attribute.OptionSet).map((o) => ({
                value: attribute.OptionSet[o].value,
                text: attribute.OptionSet[o].text
            }));
        }
        return options;
    },

    FieldLookup: async function (record, logicalName, fieldType, isRequire, elDiv, entityName, alias, isRelated = false) {
        const fieldKey = isRelated && alias ? `${alias}.${logicalName}` : logicalName;
        const lookupKey = isRelated ? fieldKey : `_${logicalName}_value`;
        let id = record[lookupKey];
        let entityNameField = "";
        let label = "";
        if (id) {
            entityNameField = record[`${lookupKey}@Microsoft.Dynamics.CRM.lookuplogicalname`];
            label = record[`${lookupKey}@OData.Community.Display.V1.FormattedValue`];
        }
        else {
            const attr = await _extensionSDK.getMetadataField(entityName, logicalName);
            entityNameField = attr.Targets?.[0];
        }

        let html = `<div style="width: 97%;position: relative;">
                    <div style="min-height: calc(1.5em + (.5rem + 2px));
                        padding: .25rem 3px;
                        font-size: .875rem;
                        border-radius: 4px;
                        border: 1px solid #ced4da;
                        display: block;
                        width: 100%;
                        font-weight: 400;
                        line-height: 1.5;
                        color: #212529;
                        background-color: #fff;
                        background-clip: padding-box;
                        -webkit-appearance: none;
                        -moz-appearance: none;
                        appearance: none;
                        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
                        position: relative;
                        ">
                            ${isRequire ? elDiv : ""}
                            <div style="display: ${id ? "inline-flex" : "none"};
                                    padding: 1px 25px 1px 5px;
                                    background: #ebf5ff;
                                    border-radius: 5px;
                                    color: rgb(17, 94, 163);
                                    position: relative;
                                    max-width: calc(100% - 28px);"
                                    onmouseover="this.style.background='rgb(207, 228, 250)'"
                                    onmouseout="this.style.background='#ebf5ff'"
                            >
                                <div style='text-decoration: underline;
                                        cursor: pointer;
                                        padding: 0 5px 0 5px;
                                        overflow: hidden;
                                        text-overflow: ellipsis;
                                        white-space: nowrap;'
                                    onclick="_extensionSDK.openViewRecord('${entityNameField}','${id}',this)"
                                    title="${label || "No Name"}"
                                >
                                    ${label || "No Name"}
                                </div>
                                <span style="position: absolute;
                                        top: -5px;
                                        right: -5px;
                                        padding: 5px 10px;
                                        cursor: pointer;" 
                                    onclick="_extensionSDK.removeDataLookup(this)">
                                    <svg
                                        width="16"
                                        height="16"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        xmlns="http://www.w3.org/2000/svg">

                                        <path
                                            d="M6 6L18 18"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"/>

                                        <path
                                            d="M18 6L6 18"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"/>

                                    </svg>
                                </span>
                            </div>
                            <input
                                value="${id || ""}"
                                style="display:none"
                                data-field="${logicalName}"
                                data-type="${fieldType}"
                                data-require="${isRequire}"
                                data-entityName="${entityName}"
                                data-alias="${alias}"
                            />
                            <span style="position: absolute;top: -3px;right: -1px;padding: 5px 10px 5px 0;cursor: pointer;" onclick="_extensionSDK.openLookup('${entityNameField}',this)"
                            data-id="${logicalName}-span"
                            entityNameField=${entityNameField}
                            >
                                <svg
                                    width="16"
                                    height="16"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg">

                                    <circle
                                        cx="11"
                                        cy="11"
                                        r="7"
                                        stroke="currentColor"
                                        stroke-width="2" />

                                    <path
                                        d="M20 20L16.5 16.5"
                                        stroke="currentColor"
                                        stroke-width="2"
                                        stroke-linecap="round" />

                                </svg>
                            </span>
                    </div>
                </div>`;
        return html;
    },

    renderInput: function (logicalName, data, type, fieldType, isRequire, elDiv, entityName, alias) {
        data = type == "datetime-local" ? BiSDK.Utils.ToDateTimeLocal(data) : data;
        let html = `<div style="position: relative;">
                        ${isRequire ? elDiv : ""}
                        <input 
                            type="${type}"
                            style="
                                min-height: calc(1.5em + (.5rem + 2px));
                                padding: .25rem .5rem;
                                font-size: .875rem;
                                border-radius: 4px;
                                border: 1px solid #ced4da;
                                display: block;
                                width: 96.5%;
                                font-weight: 400;
                                line-height: 1.5;
                                color: #212529;
                                background-color: #fff;
                                background-clip: padding-box;
                                -webkit-appearance: none;
                                -moz-appearance: none;
                                appearance: none;
                                transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
                            "
                            value="${data || ""}"
                            data-field="${logicalName}"
                            data-type="${fieldType}"
                            data-require="${isRequire}"
                            data-entityName="${entityName}" 
                            data-alias="${alias}"
                /></div>`;
        return html;
    },

    renderMutileText: function (logicalName, data, fieldType, isRequire, elDiv, entityName, alias) {
        let html = `<div style="position: relative;">
                        ${isRequire ? elDiv : ""}
                        <textarea 
                        rows="2"
                        style="
                            display: block;
                            width: 97%;
                            padding: .25rem .5rem;
                            line-height: 1.5;
                            color: #495057;
                            background-color: #fff;
                            background-clip: padding-box;
                            border: 1px solid #ced4da;
                            border-radius: .25rem;
                            transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
                        "
                        data-field="${logicalName}"
                        data-type="${fieldType}"
                        data-require="${isRequire}"
                        data-entityName="${entityName}" 
                        data-alias="${alias}"
                    >${data || ""}</textarea></div>`;
        return html;
    },

    renderOptionSet: function (logicalName, data, attr, fieldType, isRequire, elDiv, entityName, alias) {
        const options = this.getOptionsField(attr);
        let html = `<div style="position: relative;">
                        ${isRequire ? elDiv : ""}
                        <select
                            data-field="${logicalName}"
                            style="
                                display: inline-block;
                                width: 97%;
                                padding: .25rem .5rem;
                                line-height: 1.5;
                                color: #495057;
                                vertical-align: middle;
                                background:#fff url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 4 5%22%3E%3Cpath fill=%22%23343a40%22 d=%22M2 0L0 2h4zm0 5L0 3h4z%22/%3E%3C/svg%3E') no-repeat right .75rem center;
                                background-size: 8px 10px;
                                border: 1px solid #ced4da;
                                border-radius: .25rem;
                                appearance: none;
                                overflow: hidden;
                                text-overflow: ellipsis;
                                white-space: nowrap;
                            "
                            data-field="${logicalName}"
                            data-type="${fieldType}"
                            data-require="${isRequire}"
                            data-entityName="${entityName}" 
                            data-alias="${alias}"
                        >`;
        for (const option of options) {
            html += `<option value="${option.value}" ${option.value == data ? "selected" : ""}>${option.text || ""}</option>`;
        }
        html += `   </select>
                </div>`;
        return html;
    },

    renderBoolean: function (logicalName, data, disable, fieldType, isRequire, elDiv, entityName, isRelated, alias) {
        let html = `<label 
                        style="position:relative;
                            display:inline-block;
                            width:38px;
                            height:20px;
                            cursor:pointer;">
                        ${isRequire ? elDiv : ""}
                        <input
                            type="checkbox"
                            ${data ? "checked" : ""}
                            style="
                                opacity:0;
                                width:0;
                                height:0;
                            "
                            ${disable ? "disabled" : ""}
                            onchange="
                                const slider=this.nextElementSibling;
                                const circle=slider.querySelector('span');
                                if(this.checked){
                                    slider.style.background='#0d6efd';
                                    circle.style.transform='translateX(18px)';
                                }else{
                                    slider.style.background='#adb5bd';
                                    circle.style.transform='translateX(0)';
                                }
                            "
                            data-type="${fieldType}"
                            data-require="${isRequire}"
                            data-field="${logicalName}"
                            data-entityName="${entityName}"
                            data-alias="${alias}"
                            data-isrelated="${isRelated}"
                        />

                        <div style="
                            position:absolute;
                            top:0;
                            left:0;
                            right:0;
                            bottom:0;
                            background:${data ? "#0d6efd" : "#adb5bd"};
                            border-radius:999px;
                            transition:.3s;
                        ">
                            <span style="
                                position:absolute;
                                left:3px;
                                top:3px;
                                width:14px;
                                height:14px;
                                background:white;
                                border-radius:50%;
                                transition:.3s;
                                transform:${data ? "translateX(18px)" : "translateX(0)"};
                                box-shadow:0 1px 3px rgba(0,0,0,.3);
                            "></span>
                        </div>
                    </label>`;
        return html;
    },

    checkGetInputs: function (element) {
        if (!element) return null;

        const fields = element.querySelectorAll("[data-field]");
        if (fields.length > 0) {
            let arr = [];
            fields.forEach(e => { if (e.tagName == "INPUT" || e.tagName === "SELECT" || e.getAttribute("data-change")) arr.push(e) });
            return arr;
        }

        return this.checkGetInputs(element.parentElement);
    },

    getFieldsRequiredStatus: function (entityName, fieldNames) {
        const uniqueFieldNames = [...new Set(fieldNames)];
        const cacheKey = entityName;
        const cached = this._requiredFieldsCache.get(cacheKey);
        if (cached) {
            return cached.then(result => Object.fromEntries(
                uniqueFieldNames.map(name => [name, result[name] ?? false])
            ));
        }

        const request = (async () => {
            try {
                const clientUrl = top.Xrm.Utility.getGlobalContext().getClientUrl();
                const endpoint = `${clientUrl}/api/data/v9.2/EntityDefinitions(LogicalName='${entityName}')/Attributes?$select=LogicalName,RequiredLevel`;

                const response = await fetch(endpoint, {
                    method: "GET",
                    headers: {
                        "OData-MaxVersion": "4.0",
                        "OData-Version": "4.0",
                        "Accept": "application/json",
                        "Content-Type": "application/json; charset=utf-8"
                    }
                });

                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                const data = await response.json();
                const result = {};

                data.value.forEach(field => {
                    result[field.LogicalName] = field.RequiredLevel?.Value === "ApplicationRequired";
                });

                return result;
            }
            catch (error) {
                console.error("Lỗi khi lấy trạng thái Required từ Metadata:", error);
                return {};
            }
        })();

        this._requiredFieldsCache.set(cacheKey, request);
        return request.then(result => Object.fromEntries(
            uniqueFieldNames.map(name => [name, result[name] ?? false])
        ));
    },

    findDataRecord: function (element, parentOrChild) {
        if (!element) return null;

        if (element.querySelector(`[data-record-${parentOrChild}]`)) {
            return element.querySelector(`[data-record-${parentOrChild}]`);
        }

        return this.findDataRecord(element.parentElement, parentOrChild);
    },

    findDataRecord2: function (element) {
        if (!element) return null;

        if (element.querySelector(".has-record")) {
            return element.querySelector(".has-record");
        }

        return this.findDataRecord2(element.parentElement);
    },

    findElementField: function (element, parentOrChild) {
        if (!element) return null;

        if (element.className.indexOf(`${parentOrChild}-field`) != -1) {
            return element;
        }

        return this.findElementField(element.parentElement, parentOrChild);
    },

    findElementFieldDataId: function (element) {
        if (!element) return null;

        if (element.hasAttribute("data-id")) {
            return element;
        }

        return this.findElementFieldDataId(element.parentElement);
    },

    coreGrid: class {
        #gridName;
        #parentOrChild;
        constructor(gridName, parentOrChild) {
            this.#gridName = gridName;
            this.#parentOrChild = parentOrChild;
        }
        /**
            * @param {string} attribute
        */
        getAttribute(attribute) {
            let docGrid = null;
            for (const iframe of DOC.querySelectorAll("iframe")) {
                try {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    docGrid = iframeDoc.querySelector(`[data-id="mainGrid-${this.#gridName}"]`);

                    if (docGrid) {
                        break;
                    }
                } catch {
                    continue;
                }
            }

            const elParents = docGrid.querySelectorAll(`[data-id=${this.#gridName}-parent]`);
            const elChilds = docGrid.querySelectorAll(`[data-id=${this.#gridName}-child]`);
            const els = this.#parentOrChild == "parent" ? elParents : elChilds;

            return {
                /**
                    * @param {function( {value: any, target: HTMLElement} ): void} resutl
                */
                addOnChange: async (result) => {
                    await new Promise(resolve => setTimeout(resolve, 500));
                    for (const el of els) {
                        const elField = el.querySelector(`[data-field="${attribute}"]`);

                        if (!elField) {
                            continue;
                        }

                        const fieldType = elField.getAttribute("data-type");

                        if (elField._sdkChangeHandler) {
                            elField.removeEventListener("change", elField._sdkChangeHandler);
                        }

                        const changeHandler = (event) => {
                            const target = event.target;
                            let value = target.value;

                            switch (fieldType) {
                                case "string":
                                case "memo":
                                    value = target.value;
                                    break;

                                case "boolean":
                                    value = target.checked;
                                    break;

                                case "integer":
                                case "bigint":
                                    value = value === "" ? null : parseInt(value, 10);
                                    break;

                                case "decimal":
                                case "double":
                                case "money":
                                    value = value === "" ? null : parseFloat(value);
                                    break;

                                case "picklist":
                                case "state":
                                case "status": {
                                    const selectedOption = target.options?.[target.selectedIndex];

                                    value = {
                                        label: selectedOption?.text ?? "",
                                        value: target.value === "" ? null : parseInt(target.value, 10)
                                    };

                                    break;
                                }

                                case "datetime":
                                    value = value ? new Date(value) : null;
                                    break;

                                case "lookup":
                                case "customer":
                                case "owner": {
                                    const parent = elField.parentElement;
                                    const nameElement = parent?.querySelector("div div");
                                    const entityElement = parent?.querySelector(`[data-id="${attribute}-span"]`);
                                    value = {
                                        id: target.value || null,
                                        name: nameElement?.innerText?.trim() || "",
                                        entityName: entityElement?.getAttribute("entitynamefield") || ""
                                    };
                                    break;
                                }

                                default:
                                    value = target.value;
                                    break;
                            }

                            result({
                                value,
                                target
                            });
                        };

                        elField._sdkChangeHandler = changeHandler;
                        elField.addEventListener("change", changeHandler);
                        elField.dataset.hasChangeEvent = "true";
                    }
                },
                /**
                    * @param {HTMLElement} target
                */
                getValue: (target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const elField = el.querySelector(`[data-field='${attribute}']`);
                    const fieldType = elField.getAttribute("data-type");

                    let value = "";
                    switch (fieldType) {
                        case "string":
                        case "memo":
                            value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                            return {
                                value: value,
                                target: elField
                            };

                        case "boolean":
                            value = elField.checked;
                            return {
                                value: value,
                                target: elField
                            };

                        case "integer":
                        case "bigint":
                        case "decimal":
                        case "double":
                        case "money":
                            value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                            return parseFloat(value.toString());

                        case "picklist":
                        case "state":
                        case "status":
                            let option = {};
                            if (elField.tagName === "SELECT") {
                                option = {
                                    label: elField.options[elField.options.selectedIndex].text,
                                    value: parseInt(elField.value)
                                }
                            }
                            else {
                                option = {
                                    label: elField.innerText,
                                    value: parseInt(elField.getAttribute("data-value"))
                                }
                            }
                            return {
                                value: option,
                                target: elField
                            };

                        case "datetime":
                            value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                            return {
                                value: new Date(value.toString()),
                                target: elField
                            };

                        case "lookup":
                        case "customer":
                        case "owner":
                            let lookup = {};
                            if (elField.tagName === "INPUT") {
                                lookup = {
                                    id: elField.value,
                                    name: elField.parentElement.querySelector("div").querySelector("div").innerText,
                                    entityName: elField.parentElement.querySelector(`[data-id='${attribute}-span']`).getAttribute("entitynamefield")
                                };
                            }
                            else {
                                lookup = {
                                    id: elField.getAttribute("data-value"),
                                    name: elField.innerText,
                                    entityName: elField.getAttribute("entitynamefield")
                                };
                            }
                            return {
                                value: lookup,
                                target: elField
                            };
                    }
                },
                /**
                    * @param {function( {value: any, target: HTMLElement} ): void} resutl
                */
                getValues: (resutl) => {
                    for (const el of els) {
                        const elField = el.querySelector(`[data-field='${attribute}']`);
                        const fieldType = elField.getAttribute("data-type");

                        let value = "";
                        switch (fieldType) {
                            case "string":
                            case "memo":
                                value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                                resutl({
                                    value: value,
                                    target: elField
                                });
                                break;

                            case "boolean":
                                value = elField.checked;
                                resutl({
                                    value: value,
                                    target: elField
                                });
                                break;

                            case "integer":
                            case "bigint":
                            case "decimal":
                            case "double":
                            case "money":
                                value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                                resutl({
                                    value: parseFloat(value.toString()),
                                    target: elField
                                });
                                break;

                            case "picklist":
                            case "state":
                            case "status":
                                let option = {};
                                if (elField.tagName === "SELECT") {
                                    option = {
                                        label: elField.options[elField.options.selectedIndex].text,
                                        value: parseInt(elField.value)
                                    }
                                }
                                else {
                                    option = {
                                        label: elField.innerText,
                                        value: parseInt(elField.getAttribute("data-value"))
                                    }
                                }
                                resutl({
                                    value: option,
                                    target: elField
                                });
                                break;

                            case "datetime":
                                value = elField.tagName === "INPUT" ? elField.value : elField.innerHTML;
                                resutl({
                                    value: new Date(value.toString()),
                                    target: elField
                                });
                                break;

                            case "lookup":
                            case "customer":
                            case "owner":
                                let lookup = {};
                                if (elField.tagName === "INPUT") {
                                    lookup = {
                                        id: elField.value,
                                        name: elField.parentElement.querySelector("div").querySelector("div").innerText,
                                        entityName: elField.parentElement.querySelector(`[data-id='${attribute}-span']`).getAttribute("entitynamefield")
                                    };
                                }
                                else {
                                    lookup = {
                                        id: elField.getAttribute("data-value"),
                                        name: elField.innerText,
                                        entityName: elField.getAttribute("entitynamefield")
                                    };
                                }
                                resutl({
                                    value: lookup,
                                    target: elField
                                });
                                break;
                        }
                    }
                },
                /**
                    * @param {any} value
                    * @param {HTMLElement} target
                */
                setValue: (v, target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const elField = el.querySelector(`[data-field='${attribute}']`);
                    const fieldType = elField.getAttribute("data-type");

                    elField.setAttribute("data-change", true);
                    elField.setAttribute("data-value", v);
                    elField.title = v;
                    switch (fieldType) {
                        case "string":
                        case "memo":
                            elField.tagName === "INPUT" ? elField.value = v : elField.innerHTML = v;
                            return v;

                        case "boolean":
                            elField.parentElement.querySelector("div").style.background = v ? "#0d6efd" : "#adb5bd";
                            elField.parentElement.querySelector("div").querySelector("span").style.transform = v ? "translateX(18px)" : "translateX(0)";
                            return v;

                        case "integer":
                        case "bigint":
                        case "decimal":
                        case "double":
                        case "money":
                            elField.tagName === "INPUT" ? elField.value = v : elField.innerHTML = v;
                            return v;

                        case "picklist":
                        case "state":
                        case "status":
                            if (elField.tagName === "SELECT") {
                                elField.value = parseInt(v);
                            }
                            else {
                                let entityName = elField.getAttribute("data-entityName");
                                _extensionSDK.getMetadataField(entityName, attribute).then((attr) => {
                                    let optionV = _extensionSDK.getOptionsField(attr).find(o => o.value === v);
                                    elField.innerText = optionV.text;
                                    elField.title = BiSDK.Utils.ToDateTimeLocal(optionV.text);
                                });
                            }
                            return v;

                        case "datetime":
                            elField.tagName === "INPUT" ? elField.value = BiSDK.Utils.ToDateTimeLocal(v) : elField.innerHTML = BiSDK.Utils.FormatDateTimeVN(v);
                            elField.title = BiSDK.Utils.ToDateTimeLocal(v);
                            return v;

                        case "lookup":
                        case "customer":
                        case "owner":
                            if (elField.tagName === "INPUT") {
                                elField.value = v["id"];
                                elField.parentElement.querySelector("div").querySelector("div").innerText = v["name"];
                                elField.parentElement.querySelector(`[data-id='${attribute}-span']`).setAttribute("entitynamefield", v["entityName"]);
                            }
                            else {
                                elField.value = elField.setAttribute("data-value", v["id"]);
                                elField.innerText = v["name"];
                                elField.setAttribute("entitynamefield", v["entityName"]);
                                elField.title = v["name"];
                                elField.onclick = () => _extensionSDK.openViewRecord(v["entityName"], v["id"], elField);
                            }
                            return v;
                    }

                },
                /**
                    * @param {string} fetchXml
                    * @param {HTMLElement} target
                */
                setFetchLookup: async (fetchXml, target) => {
                    await new Promise((resolve) => { setTimeout(resolve, 500) });

                    const el = _extensionSDK.findElementFieldDataId(target);
                    if (!el) return;
                    const span = el.querySelector(`[data-id='${attribute}-span']`);
                    if (!span) return;
                    const entityName = span.getAttribute("entityNameField");
                    span.onclick = () => {
                        _extensionSDK.openLookupFetchXml(fetchXml, entityName, span);
                    }
                    return;
                },
                /**
                    * @param {boolean} bool
                    * @param {HTMLElement} target
                */
                setDisabled: async (bool, target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const elField = el.querySelector(`[data-field='${attribute}']`);
                    const elRecord = _extensionSDK.findDataRecord(elField, this.#parentOrChild);
                    const record = JSON.parse(elRecord.getAttribute(`data-record-${this.#parentOrChild}`));
                    const elOverField = _extensionSDK.findElementField(elField, this.#parentOrChild);
                    const entityName = elField.getAttribute("data-entityName");
                    const alias = elField.getAttribute("data-alias");
                    elOverField.innerHTML = "";
                    if (!bool) {
                        let html = await BiSDK.UI.FillFieldDataEdit(record, attribute, entityName, alias, false);
                        elOverField.insertAdjacentHTML("beforeend", html);
                        return bool;
                    }
                    else {
                        let html = await BiSDK.UI.FillFieldData(record, attribute, entityName, alias, false);
                        elOverField.insertAdjacentHTML("beforeend", html);
                        return bool;
                    }
                },
                /**
                    * @param {boolean} bool
                    * @param {HTMLElement} target
                */
                setRequired: async (bool, target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const elField = el.querySelector(`[data-field='${attribute}']`);
                    if (elField && (elField.tagName === "INPUT" || elField.tagName === "SELECT")) {
                        const parentElField = elField.parentElement;
                        if (!bool) {
                            parentElField.querySelectorAll(".span-required").forEach(e => e.remove());
                            elField.setAttribute("data-require", bool);
                        }
                        else {
                            let html = `<span class="span-required" style="position:absolute;top:-14px;right:0;z-index:2;color:#d13438;font-size:14px;font-weight:600;pointer-events:none;">*</span>`;
                            parentElField.insertAdjacentHTML("afterbegin", html);
                        }
                        elField.setAttribute("data-require", bool);
                    }
                    return;
                },
            }
        }

        /**
            * @param {HTMLElement} target
        */
        setDisabledRow = async (target) => {
            const el = _extensionSDK.findElementFieldDataId(target);
            const elFields = el.querySelectorAll(`[data-field]`);
            for (const elField of elFields) {
                const attribute = elField.getAttribute("data-field");
                const elRecord = _extensionSDK.findDataRecord(elField, this.#parentOrChild);
                const record = JSON.parse(elRecord.getAttribute(`data-record-${this.#parentOrChild}`));
                const elOverField = _extensionSDK.findElementField(elField, this.#parentOrChild);
                const entityName = elField.getAttribute("data-entityName");
                const alias = elField.getAttribute("data-alias");
                elOverField.innerHTML = "";

                let html = await BiSDK.UI.FillFieldData(record, attribute, entityName, alias, false);
                elOverField.insertAdjacentHTML("beforeend", html);
            }
            return;
        }

        Button = {
            Save: {
                /**
                    * @param {HTMLElement} target
                */
                show: (target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const button = el.querySelector(`[data-idbutton-save=button-grid-save-${this.#gridName}]`);
                    button.style.display = "inline-block";
                },
                /**
                    * @param {HTMLElement} target
                */
                hide: (target) => {
                    const el = _extensionSDK.findElementFieldDataId(target);
                    const button = el.querySelector(`[data-idbutton-save=button-grid-save-${this.#gridName}]`);
                    button.style.display = "none";
                }
            }
        }

        UI = {
            /**
                * @param {string} color
                * @param {HTMLElement} target
            */
            setBackgroudColor: (color, target) => {
                const el = _extensionSDK.findElementFieldDataId(target);
                el.style.background = color ? color : "white";
            },
        }
    },
};

const BiSDK = {
    UI: {
        /**
            * @param {string} message
            * @param {"success"|"error"|"warning"|"info"} [type="success"]
            * @param {string} title
        */
        ShowAlert(message, type = "success", title) {
            const themes = {
                success: { icon: "✓", color: "#22c55e" },
                error: { icon: "✕", color: "#ef4444" },
                warning: { icon: "⚠", color: "#f59e0b" },
                info: { icon: "ⓘ", color: "#3b82f6" }
            };
            const theme = themes[type] ?? themes.info;
            const container = DOC.getElementById("toast-container") ?? Object.assign(DOC.body.appendChild(DOC.createElement("div")), {
                id: "toast-container"
            });

            Object.assign(container.style, {
                position: "fixed",
                top: "24px",
                right: "24px",
                zIndex: "9999999999",
                display: "flex",
                flexDirection: "column",
                gap: "12px"
            });

            const toast = DOC.createElement("div");
            toast.innerHTML = `
                <div class="toast-content">
                    <div class="toast-icon">${theme.icon}</div>
                    <div class="toast-body">
                        <div class="toast-title">
                            ${title || type.toUpperCase()}
                        </div>
                        <div class="toast-message">
                            ${message}
                        </div>
                    </div>
                    <button class="toast-close">×</button>
                </div>
                <div class="toast-progress"></div>
            `;

            Object.assign(toast.style, {
                width: "360px",
                overflow: "hidden",
                borderRadius: "16px",
                background: "rgba(255,255,255,.92)",
                backdropFilter: "blur(20px)",
                boxShadow: "0 10px 30px rgba(0,0,0,.12)",
                borderLeft: `4px solid ${theme.color}`,
                opacity: 0,
                transform: "translateX(120%)",
                transition: "all .35s cubic-bezier(.22,1,.36,1)"
            });

            toast.querySelector(".toast-icon").style.cssText = `
                width:40px;
                height:40px;
                border-radius:50%;
                background:${theme.color};
                color:white;
                display:flex;
                align-items:center;
                justify-content:center;
                font-weight:bold;
                box-shadow:0 0 18px ${theme.color}55;
                flex-shrink:0;
            `;

            toast.querySelector(".toast-content").style.cssText = `
                display:flex;
                gap:12px;
                padding:10px;
                align-items:flex-start;
            `;

            toast.querySelector(".toast-body").style.cssText = `
                flex:1;
            `;

            toast.querySelector(".toast-title").style.cssText = `
                font-weight:600;
                font-size:14px;
                color:#111827;
            `;

            toast.querySelector(".toast-message").style.cssText = `
                margin-top:4px;
                color:#6b7280;
                line-height:1.5;
                font-size:13px;
            `;

            toast.querySelector(".toast-close").style.cssText = `
                border:none;
                background:none;
                cursor:pointer;
                font-size:24px;
                color:#9ca3af;
            `;

            const progress = toast.querySelector(".toast-progress");
            progress.style.cssText = `
                height:3px;
                width:100%;
                background:${theme.color};
                transform-origin:left;
            `;
            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.style.opacity = 1;
                toast.style.transform = "translateX(0)";
            });

            progress.animate(
                [
                    { width: "100%" },
                    { width: "0%" }
                ],
                {
                    duration: 3000,
                    fill: "forwards"
                }
            );

            const remove = () => {
                toast.style.opacity = 0;
                toast.style.transform = "translateX(120%)";

                setTimeout(() => {
                    toast.remove();

                    if (!container.children.length)
                        container.remove();
                }, 350);
            };
            toast.querySelector(".toast-close").addEventListener("click", remove);
            setTimeout(remove, 3000);
        },

        Modal: {
            /**
            * @typedef {Object} ShowOptions
            * @property {string} title
            * @property {string} content
            * @property {string} footer
            * @property {number|string} width
            * @property {number|string} height
            * @property {boolean} closeOnBackdrop
            * @property {boolean} visibleX
            * @property {Function} cancelCallback
            * @property {Function} saveCallback
            */
            /**
            * @param {ShowOptions} options
            */
            show({ title = "", content = "", footer = "", width = 800, height = "auto", closeOnBackdrop = true, visibleX = true, cancelCallback = async () => true, saveCallback = async () => true } = {}) {
                _extensionSDK._init();
                const overlay = DOC.createElement("div");
                overlay.className = "modal-overlay";
                overlay.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-header">
                        <div class="modal-title">
                            ${title}
                        </div>
                        ${visibleX ?
                        `<button class="modal-close">
                            ✕
                        </button>`: ""}
                    </div>

                    <div class="modal-body">
                        ${content}
                    </div>

                    ${footer ? footer : `
                            <div class="modal-footer">
                                <button type="button" class="modal-btn modal-btn-secondary modal-cancel">
                                    Cancel
                                </button>

                                <button type="button" class="modal-btn modal-btn-primary modal-save">
                                    OK
                                </button>
                            </div>
                            `
                    }
                    </div>
                `;
                DOC.body.appendChild(overlay);

                const dialog = overlay.querySelector(".modal-dialog");
                let endWidth = "";
                if (width.toString().indexOf("%") != -1) endWidth = width;
                else if (width == "auto") endWidth = width;
                else endWidth = width + "px";

                let endHeight = "";
                if (height.toString().indexOf("%") != -1) endHeight = height;
                else if (height == "auto") endHeight = height;
                else endHeight = height + "px";

                dialog.style.setProperty("--modal-width", `${endWidth}`);
                dialog.style.setProperty("--modal-height", `${endHeight}`);

                requestAnimationFrame(() => {
                    overlay.classList.add("show");
                });

                const close = () => {
                    overlay.classList.remove("show");
                    setTimeout(() => {
                        overlay.remove();
                    }, 250);
                };

                const setLoading = (button, loading) => {
                    if (!button) return;
                    if (loading) {
                        button.disabled = true;
                        button.dataset.originalText = button.innerHTML;
                        button.innerHTML = "Wait...";
                    }
                    else {
                        button.disabled = false;
                        button.innerHTML = button.dataset.originalText;
                    }
                };

                const cancelBtn = overlay.querySelector(".modal-cancel");
                const saveBtn = overlay.querySelector(".modal-save");
                const closeBtn = overlay.querySelector(".modal-close");
                closeBtn.onclick = close;

                if (cancelBtn) {
                    cancelBtn.onclick = async () => {
                        try {
                            BiSDK.UI.Loading.show();
                            setLoading(cancelBtn, true);
                            const result = await cancelCallback();
                            if (result === false)
                                return;

                            close();
                        }
                        catch (ex) {
                            throw (ex);
                        }
                        finally {
                            setLoading(cancelBtn, false);
                            BiSDK.UI.Loading.hide();
                        }
                    };
                }

                if (saveBtn) {
                    saveBtn.onclick = async () => {
                        try {
                            BiSDK.UI.Loading.show();
                            setLoading(saveBtn, true);
                            const result = await saveCallback();
                            if (result === false)
                                return;
                            close();
                        }
                        catch (ex) {
                            throw (ex);
                        }
                        finally {
                            setLoading(saveBtn, false);
                            BiSDK.UI.Loading.hide();
                        }
                    };
                }

                overlay.onclick = (e) => {
                    if (closeOnBackdrop && e.target === overlay) {
                        close();
                        BiSDK.UI.Loading.hide();
                    }
                };

                return {
                    close,
                    body: overlay.querySelector(".modal-body"),
                    element: overlay,
                    loadingModal: () => {
                        BiSDK.UI.Loading.global.show();
                    }
                };
            }
        },

        Loading: {
            /**
                * @param {string} text
            */
            show(text = "Wait...") {
                const style = DOC.createElement("style");
                style.textContent = `
                    #loader{
                        position:fixed;
                        inset:0;
                        display:flex;
                        flex-direction:column;
                        align-items:center;
                        justify-content:center;
                        background:rgba(255,255,255,.15);
                        backdrop-filter:blur(8px);
                        z-index:999999;
                    }

                    .loader-dots{
                        display:flex;
                        gap:10px;
                    }

                    .loader-dot{
                        width:10px;
                        height:10px;
                        border-radius:50%;
                        background:#2563eb;
                        animation:loader-bounce 1.2s infinite ease-in-out;
                    }

                    .loader-dot:nth-child(2){
                        animation-delay:.15s;
                    }

                    .loader-dot:nth-child(3){
                        animation-delay:.3s;
                    }

                    .loader-text{
                        margin-top:18px;
                        font-family: Segoe UI, sans-serif;
                        font-size:16px;
                        font-weight:500;
                        color:#334155;
                    }

                    @keyframes loader-bounce{
                        0%,80%,100%{
                            transform:translateY(0);
                            opacity:.3;
                        }

                        40%{
                            transform:translateY(-8px);
                            opacity:1;
                        }
                    }
                `;

                document.head.appendChild(style);

                const loader = document.createElement("div");
                loader.id = "loader";
                loader.innerHTML = `
                    <div class="loader-dots">
                        <div class="loader-dot"></div>
                        <div class="loader-dot"></div>
                        <div class="loader-dot"></div>
                    </div>

                    <div class="loader-text">
                        ${text}
                    </div>
                `;

                document.body.appendChild(loader);
            },
            hide() {
                document.getElementById("loader")?.remove();
            },
            global: {
                /**
                    * @param {string} text
                */
                show(text = "Wait...") {
                    const style = DOC.createElement("style");
                    style.textContent = `
                    #loader{
                        position:fixed;
                        inset:0;
                        display:flex;
                        flex-direction:column;
                        align-items:center;
                        justify-content:center;
                        background:rgba(255,255,255,.15);
                        backdrop-filter:blur(8px);
                        z-index:999999;
                    }

                    .loader-dots{
                        display:flex;
                        gap:10px;
                    }

                    .loader-dot{
                        width:10px;
                        height:10px;
                        border-radius:50%;
                        background:#2563eb;
                        animation:loader-bounce 1.2s infinite ease-in-out;
                    }

                    .loader-dot:nth-child(2){
                        animation-delay:.15s;
                    }

                    .loader-dot:nth-child(3){
                        animation-delay:.3s;
                    }

                    .loader-text{
                        margin-top:18px;
                        font-family: Segoe UI, sans-serif;
                        font-size:16px;
                        font-weight:500;
                        color:#334155;
                    }

                    @keyframes loader-bounce{
                        0%,80%,100%{
                            transform:translateY(0);
                            opacity:.3;
                        }

                        40%{
                            transform:translateY(-8px);
                            opacity:1;
                        }
                    }
                `;

                    DOC.head.appendChild(style);

                    const loader = DOC.createElement("div");
                    loader.id = "loader";
                    loader.innerHTML = `
                    <div class="loader-dots">
                        <div class="loader-dot"></div>
                        <div class="loader-dot"></div>
                        <div class="loader-dot"></div>
                    </div>

                    <div class="loader-text">
                        ${text}
                    </div>
                `;

                    DOC.body.appendChild(loader);
                },
                hide() {
                    DOC.getElementById("loader")?.remove();
                },
            }
        },

        FormNotification: {
            /**
                * @param {string} message
                * @param {"success"|"error"|"warning"|"info"} [type="success"]
                * @param {string} id
                * @param {number} timeclear
            */
            show(message, type = "success", id, timeclear) {
                const container = _extensionSDK.getContainer();
                id = id || `msg_${Date.now()}`;
                const old = DOC.getElementById(id);
                if (old) {
                    old.remove();
                }
                const config = _extensionSDK.getConfig(type);
                const item = DOC.createElement("div");
                item.id = id;
                item.style.cssText = `
                    display:flex;
                    align-items:center;
                    margin:4px 0;
                    padding:10px 12px;
                    background:${config.bg};
                    border-left:4px solid ${config.border};
                    font-family:Segoe UI;
                    font-size:13px;
                    min-height:40px;
                    box-sizing:border-box;
                `;
                item.innerHTML = `
                    <span style="margin-right:8px">
                        ${config.icon}
                    </span>

                    <span style="flex:1">
                        ${message}
                    </span>

                    <span
                        style="
                            cursor:pointer;
                            font-weight:bold;
                            padding-left:10px;
                        ">
                        ✕
                    </span>
                `;

                item.querySelector("span:last-child").addEventListener("click", function () {
                    item.remove();
                });

                container.appendChild(item);

                setTimeout(() => {
                    item.remove()
                }, timeclear);
                return id;
            },

            /**
                * @param {string} id
            */
            clear(id) {
                const item = DOC.getElementById(id);
                if (item) {
                    item.remove();
                }
            },

            clearAll() {
                const container = DOC.getElementById(_extensionSDK.CONTAINER_ID);
                if (container) {
                    container.innerHTML = "";
                }
            }
        },

        /**
            * @property {string} entityName
            * @property {string} buttonName
            * @property {string} tooltip
            * @property {number} index
            * @property {Function} visibleButton
            * @property {Function} onClick
         */
        AddButton: async function ({ entityName = "account", buttonName = "Undefined", tooltip = "", index = 2, visibleButton = async () => true, onClick = async () => { } } = {}) {
            let checkMore = false;
            await new Promise(resolve => {
                setTimeout(() => {
                    const commandBar = DOC.querySelector(`[data-id="CommandBar"][data-lp-id="commandbar-Form:${entityName}"]`);
                    checkMore = commandBar.querySelector(".MoreVertical-symbol") !== null;
                    resolve();
                }, 1000);
            });

            if (checkMore) {
                const buttonId = `bisdk-${buttonName.replace(/\s+/g, "-").toLowerCase()}`;
                const addToOverflow = async () => {
                    const menus = [...DOC.querySelectorAll('[role="menu"]')].filter(x => x.offsetParent !== null);
                    const menu = menus.at(-1);

                    if (!menu) {
                        return;
                    }

                    if (menu.querySelector(`#${buttonId}`)) {
                        return;
                    }

                    const button = await _extensionSDK.renderButton({
                        entityName: entityName,
                        buttonName: buttonName,
                        tooltip: tooltip,
                        index: index,
                        visibleButton: visibleButton,
                        onClick: onClick
                    });
                    if (!button) {
                        return;
                    }

                    button.id = buttonId;
                    menu.appendChild(button);
                };

                setTimeout(() => {
                    DOC.querySelectorAll("li").forEach(li => {
                        li.addEventListener("click", function (e) {
                            const moreButton = e.target.closest(".MoreVertical-symbol");
                            const moreButton1 = e.target.querySelector(".MoreVertical-symbol");
                            if (moreButton || moreButton1) {
                                setTimeout(() => {
                                    addToOverflow();
                                }, 100);
                            }
                        });
                    });
                }, 1000);

                return {
                    buttonId,
                    dispose() {
                        DOC.removeEventListener("click", addToOverflow);
                    }
                };
            }
            else {
                _extensionSDK.renderButton({ entityName, buttonName, tooltip, index, visibleButton, onClick, more: false });
            }
        },

        /**
            * @property {object} record
            * @property {string} logicalName
            * @property {object} objColor
         */
        FillFieldData: async (record, logicalName, entityName, alias, isRelated) => {
            alias = alias !== "null" && alias !== "undefined" ? alias : null;
            const attr = await _extensionSDK.getMetadataField(entityName, logicalName);
            const fieldType = attr.AttributeTypeName;
            const fieldKey = isRelated && alias ? `${alias}.${logicalName}` : logicalName;
            const formattedFieldKey = `${fieldKey}@OData.Community.Display.V1.FormattedValue`;

            if (fieldType == "lookup" || fieldType == "customer" || fieldType == "owner") {
                const lookupKey = isRelated ? fieldKey : `_${logicalName}_value`;
                const entityNameField = record[`${lookupKey}@Microsoft.Dynamics.CRM.lookuplogicalname`];
                const label = record[`${lookupKey}@OData.Community.Display.V1.FormattedValue`];
                const id = record[lookupKey];
                if (!id) return "";

                return `<div style="color: rgb(17, 94, 163);display:inline-block;padding: 0px 5px 0px 0px;border-radius: 4px;width: 100%;" 
                                onmouseover="this.style.background='rgb(207, 228, 250)'" 
                                onmouseout="this.style.background=''"
                            >
                                <div style='text-decoration: underline;
                                        cursor: pointer;
                                        overflow: hidden;
                                        text-overflow: ellipsis;
                                        white-space: nowrap;'
                                    onclick="_extensionSDK.openViewRecord('${entityNameField}','${id}',this)"
                                    title="${label}"
                                    entityNameField="${entityNameField}"
                                    data-field="${logicalName}"
                                    data-value="${id}"
                                    data-type="${fieldType}"
                                    data-entityName="${entityName}" 
                                    data-alias="${alias}" 
                                >
                                    ${label || "No Name"}
                                </div>
                            </div>`;
            }
            else if (fieldType == "picklist" || fieldType == "status" || fieldType == "state") {
                return `<div style="display: inline-block;
                            padding: 5px 10px;
                            line-height: 1;
                            text-align: center;
                            border-radius: 20px;"
                            data-field="${logicalName}"
                            data-type="${fieldType}"
                            data-value="${record[fieldKey] ?? ""}"
                            data-entityName="${entityName}"
                            data-alias="${alias}" 
                            >
                            ${record[formattedFieldKey] || ""}
                        </div>`;
            }
            else if (fieldType == "boolean") {
                return _extensionSDK.renderBoolean(logicalName, record[fieldKey], true, fieldType, false, "", entityName, isRelated);
            }
            else {
                const value = record[formattedFieldKey] ?? record[fieldKey] ?? "";
                const typeNumber = ["integer", "bigint", "decimal", "double", "money"].includes(fieldType);
                return `<div
                            data-field="${logicalName}"
                            data-type="${fieldType}"
                            data-entityName="${entityName}" 
                            data-value="${value}"
                            data-alias="${alias}" 
                            style="
                                    width:100%;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    white-space: nowrap;
                                    ${typeNumber ? "text-align: right" : ""}
                                "
                            title="${value}"
                        >
                                ${value}
                        </div>`;
            }
        },

        /**
            * @property {object} record
            * @property {string} logicalName
         */
        FillFieldDataEdit: async (record, logicalName, entityName, alias, isRelated) => {
            alias = alias !== "null" && alias !== "undefined" ? alias : null;
            const [attr, requiredConfig] = await Promise.all([
                _extensionSDK.getMetadataField(entityName, logicalName),
                _extensionSDK.getFieldsRequiredStatus(entityName, [logicalName])
            ]);
            const fieldType = attr.AttributeTypeName;
            const fieldKey = isRelated && alias ? `${alias}.${logicalName}` : logicalName;
            const isRequired = requiredConfig[logicalName];
            const divRequire = '<span class="span-required" style="position:absolute;top:-14px;right:0;z-index:2;color:#d13438;font-size:14px;font-weight:600;pointer-events:none;">*</span>';

            switch (fieldType) {
                case "string":
                    return _extensionSDK.renderInput(logicalName, record[fieldKey], "text", fieldType, isRequired, divRequire, entityName, alias);

                case "memo":
                    return _extensionSDK.renderMutileText(logicalName, record[fieldKey], fieldType, isRequired, divRequire, entityName, alias);

                case "integer":
                case "bigint":
                case "decimal":
                case "double":
                case "money":
                    return _extensionSDK.renderInput(logicalName, record[fieldKey], "number", fieldType, isRequired, divRequire, entityName, alias);

                case "boolean":
                    return _extensionSDK.renderBoolean(logicalName, record[fieldKey], false, fieldType, isRequired, divRequire, entityName, isRelated, alias);

                case "datetime":
                    return _extensionSDK.renderInput(logicalName, record[fieldKey], "datetime-local", fieldType, isRequired, divRequire, entityName, alias);

                case "picklist":
                case "state":
                case "status":
                    return _extensionSDK.renderOptionSet(logicalName, record[fieldKey], attr, fieldType, isRequired, divRequire, entityName, alias);

                case "lookup":
                case "customer":
                case "owner":
                    return await _extensionSDK.FieldLookup(record, logicalName, fieldType, isRequired, divRequire, entityName, alias, isRelated);
            }
        },
    },
    Form: {
        /**
            * @param {any} formContext
        */
        lockAllForm(formContext) {
            formContext.ui.controls.forEach(function (control) {
                if (control && control.setDisabled) {
                    control.setDisabled(true);
                }
            });
        },

        /**
            * @param {any} formContext
            * @param {string[]} sections
            * @param {boolean} isLock
        */
        lockFieldBySection(formContext, sections, isLock) {
            var tabs = formContext.ui.tabs.getAll();
            if (tabs && tabs.length > 0) {
                tabs.forEach(tab => {
                    if (sections && sections.length > 0) {
                        sections.forEach(secLock => {
                            var isExisting = tab.sections.get(secLock);
                            if (isExisting != null) {
                                var controls = isExisting.controls.get();
                                controls.forEach(function (control) {
                                    if (control.setDisabled)
                                        control.setDisabled(isLock);
                                })
                            }
                        });
                    }
                });
            }
        },

        /**
            * @param {any} formContext
            * @param {string[]} attributers
            * @param {"required"|"none"} condition
        */
        setRequiredLevels(formContext, attributers, condition = "none") {
            for (var i = 0; i < attributers.length; i++) {
                if (attributers[i] != '' && attributers[i] != null && attributers[i] != undefined) {
                    formContext.getAttribute(attributers[i]).setRequiredLevel(condition);
                }
            }
        },

        /**
            * @param {any} formContext
            * @param {string[]} attributers
            * @param {boolean} value
        */
        setValues(formContext, attributers, value) {
            for (var i = 0; i < attributers.length; i++) {
                if (attributers[i] != '' && attributers[i] != null && attributers[i] != undefined) {
                    formContext.getAttribute(attributers[i]).setValue(value);
                }
            }
        },

        /**
            * @param {any} formContext
            * @param {string[]} attributers
            * @param {boolean} isDisabled
        */
        setDisableds(formContext, attributers, isDisabled) {
            for (var i = 0; i < attributers.length; i++) {
                if (attributers[i] != '' && attributers[i] != null && attributers[i] != undefined) {
                    formContext.getControl(attributers[i]).setDisabled(isDisabled);
                }
            }
        },

        /**
            * @param {any} formContext
            * @param {string[]} attributers
            * @param {boolean} isVisible
        */
        setVisibles(formContext, attributers, isVisible) {
            for (var i = 0; i < attributers.length; i++) {
                if (attributers[i] != '' && attributers[i] != null && attributers[i] != undefined) {
                    formContext.getControl(attributers[i]).setVisible(isVisible);
                }
            }
        },

        /**
            * @param {any} formContext
            * @param {string[]} listSectionName
            * @param {boolean} isHide
        */
        showHideTabs(formContext, listTabName, isHide) {
            for (var i = 0; i < listTabName.length; i++) {
                if (listTabName)
                    formContext.ui.tabs.get(listTabName[i]).setVisible(isHide);
            }
        },

        /**
            * @param {any} formContext
            * @param {string} tabName
            * @param {string[]} listSectionName
            * @param {boolean} isHide
        */
        showHideSection(formContext, listSectionName, isHide) {
            var tabs = formContext.ui.tabs.getAll();
            if (tabs && tabs.length > 0) {
                tabs.forEach(tab => {
                    for (var i = 0; i < listSectionName.length; i++) {
                        var section = tab.sections.get(listSectionName[i]);
                        if (section)
                            section.setVisible(isHide);
                    }
                });
            }
        },
    },
    WebApi: {
        /**
            * @param {string} entityName
            * @param {string} fetchXml
        */
        retrieveAllRecords(entityName, fetchXml, page = 0, pagingCookie = null) {
            if (!page) {
                page = 0;
            }

            return _extensionSDK.retrievePage(entityName, fetchXml, page + 1, pagingCookie).then(
                function success(pageResults) {
                    if (pageResults.fetchXmlPagingCookie) {
                        return BISDK.WebApi.retrieveAllRecords(
                            entityName,
                            fetchXml,
                            page + 1,
                            pageResults.fetchXmlPagingCookie
                        ).then(
                            function success(results) {
                                if (results) {
                                    return pageResults.entities.concat(results);
                                }
                            },
                            function error(e) {
                                throw e;
                            }
                        );
                    } else {
                        return pageResults.entities;
                    }
                },
                function error(e) {
                    throw e;
                }
            );
        },

        /**
            * @param {string} entityName
            * @param {string} fetchXml
        */
        retrieveMultipleRecords: async function (entityName, fetchXml) {
            fetchXml = "?fetchXml=" + encodeURIComponent(fetchXml);
            return await top.Xrm.WebApi.retrieveMultipleRecords(entityName, fetchXml);
        },

        /**
            * @param {string} entityName
            * @param {string} entityId
            * @param {string[]} attributes
        */
        retrieveRecord: async function (entityName, entityId, attributes) {
            return await top.Xrm.WebApi.retrieveRecord(entityName, entityId, `?$select=${attributes.join(",").trim()}`)
        },

        /**
            * @param {string} entityName
            * @param {string} entityId
            * @param {object} data
        */
        updateRecord: async function (entityName, entityId, data) {
            return await top.Xrm.WebApi.updateRecord(entityName, entityId, data);
        },

        /**
            * @param {string} entityName
            * @param {object} data
        */
        createRecord: async function (entityName, data) {
            return await top.Xrm.WebApi.createRecord(entityName, data)
        },

        /**
            * @param {string} entityName
            * @param {string} id
        */
        deleteRecord: async function (entityName, id) {
            return await top.Xrm.WebApi.deleteRecord(entityName, id)
        },

        /**
            * @param {string} customAPIName
            * @param {string} entityID
            * @param {string} actionName
            * @param {object} data
        */
        callCustomAPI(customAPIName, entityID, actionName, data) {
            return top.Xrm.WebApi.online.execute({
                getMetadata: function () {
                    return {
                        boundParameter: null,
                        parameterTypes: {
                            msm_ActionName: { typeName: "Edm.String", structuralProperty: 1 },
                            msm_PrimaryEntityId: { typeName: "Edm.String", structuralProperty: 1 },
                            msm_Data: { typeName: "Edm.String", structuralProperty: 1 },
                        },
                        operationType: 0,
                        operationName: customAPIName
                    };
                },
                msm_PrimaryEntityId: entityID,
                msm_ActionName: actionName,
                msm_Data: data ? JSON.stringify(data) : ""
            }).then(
                function (response) {
                    return response;
                },
                function (error) {
                    throw error;
                }
            );
        },

        /**
            * @param {any} formContext
            * @param {string[]} roleName
        */
        async roleIsValid(formContext, roleName) {
            var valid = false;
            var fetchXml = `
                <fetch no-lock='true'>
                <entity name='systemuserroles'>
                    <attribute name='systemuserroleid' />
                    <attribute name='roleid' />
                    <filter type='and'>
                    <condition attribute='systemuserid' operator='eq' value='${formContext.context.getUserId()}'/>
                    <condition entityname='role' attribute='name' operator='not-null'/>
                    </filter>
                    <link-entity name='role' from='roleid' to='roleid' link-type='inner' alias='role'>
                    <attribute name='name' alias='rolename' />
                    </link-entity>
                </entity>
                </fetch>`;
            const rs = await this.retrieveMultipleRecords("systemuserroles", fetchXml);
            const data = rs.entities;
            if (data.length > 0) {
                for (let index = 0; index < data.length; index++) {
                    const item = data[index];
                    if (item["rolename"] && roleName.indexOf(item["rolename"]) != -1)
                        valid = true;
                }
            }
            return valid;
        },
    },
    Utils: {
        /**
            * @param {Date} date
        */
        FormatDateVN: (date) => {
            const d = new Date(date);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            return `${day}/${month}/${year}`;
        },

        /**
            * @param {Date} date
        */
        FormatDateFetch: (date) => {
            const d = new Date(date);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            return `${year}/${month}/${day}`;
        },

        /**
            * @param {Date} date
        */
        FormatDateTimeVN: (date) => {
            const d = new Date(date);
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const year = d.getFullYear();
            const hours = String(d.getHours()).padStart(2, '0');
            const minutes = String(d.getMinutes()).padStart(2, '0');
            return `${day}/${month}/${year} ${hours}:${minutes}`;
        },

        /**
            * @param {string} tableId
            * @param {string} fileName
        */
        ExportTableToExcel(tableId, fileName = "Export") {

            const table = document.getElementById(tableId);

            if (!table) {
                throw new Error(`Không tìm thấy table: ${tableId}`);
            }

            const cloneTable = table.cloneNode(true);

            const sourceCells = table.querySelectorAll("th,td");
            const cloneCells = cloneTable.querySelectorAll("th,td");

            sourceCells.forEach((cell, index) => {

                const style = getComputedStyle(cell);

                cloneCells[index].style.backgroundColor =
                    style.backgroundColor;

                cloneCells[index].style.color =
                    style.color;

                cloneCells[index].style.fontWeight =
                    style.fontWeight;

                cloneCells[index].style.fontSize =
                    style.fontSize;

                cloneCells[index].style.fontFamily =
                    style.fontFamily;

                cloneCells[index].style.textAlign =
                    style.textAlign;

                cloneCells[index].style.border =
                    style.border;

                cloneCells[index].style.whiteSpace =
                    "nowrap";
            });

            const html = `
    <html
        xmlns:o="urn:schemas-microsoft-com:office:office"
        xmlns:x="urn:schemas-microsoft-com:office:excel"
        xmlns="http://www.w3.org/TR/REC-html40">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        ${cloneTable.outerHTML}
    </body>
    </html>`;

            const blob = new Blob(
                [html],
                {
                    type: "application/vnd.ms-excel;charset=utf-8;"
                }
            );

            const url = URL.createObjectURL(blob);

            const link = document.createElement("a");

            link.href = url;
            link.download = `${fileName}.xls`;

            document.body.appendChild(link);

            link.click();

            document.body.removeChild(link);

            URL.revokeObjectURL(url);
        },

        /**
            * @param {number|string} value
            * @param {number} decimals
            * @returns {string}
        */
        FormatNumber(value, decimals = 0) {
            const num = Number(value);
            if (isNaN(num)) {
                return "";
            }

            return num.toLocaleString("en-US", {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            });
        },

        /**
            * @param {number|string} value
            * @param {number} decimals
            * @param {string} currency
            * @returns {string}
        */
        FormatMoney(value, decimals = 0, currency = "₫") {
            const num = Number(value);
            if (isNaN(num)) {
                return "";
            }
            return num.toLocaleString("vi-VN", {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals
            }) + " " + currency;
        },

        /**
            * @param {object} record
            * @param {string} logicalName
        */
        GetNameLookup(record, logicalName) {
            return record[`_${logicalName}_value@OData.Community.Display.V1.FormattedValue`] || "";
        },

        /**
            * @param {string} dateString
        */
        ToDateTimeLocal(dateString) {
            const date = new Date(dateString);
            const offset = date.getTimezoneOffset() * 60000;
            return new Date(date.getTime() - offset).toISOString().slice(0, 16);
        },

        /**
            * @property {string} entityName
            * @property {any} element
         */
        GetDataFields: async (entityName, element) => {
            let lsInputs = _extensionSDK.checkGetInputs(element);
            if (!lsInputs) return;
            let obj = {};
            for (const el of lsInputs) {
                let fieldName = el.getAttribute("data-field");
                let dataType = el.getAttribute("data-type");
                let dataRequire = el.getAttribute("data-require");
                let dataEntityName = el.getAttribute("data-entityName");
                let valueField = dataType == "boolean" ? el.checked : el.value || el.innerText || "";
                let recordEl = _extensionSDK.findDataRecord2(el);
                let record = JSON.parse(recordEl.getAttribute("data-record-parent") || recordEl.getAttribute("data-record-child") || "{}");
                let initValue = record[`_${fieldName}_value`] || record[fieldName];


                if (dataEntityName) {
                    if (dataEntityName != entityName) return obj;
                }

                if (dataRequire == "true" && (valueField == null || valueField == "")) {
                    throw ({ message: "Vui lòng nhập đủ các field bắt buộc!" });
                }
                if (initValue == valueField) {
                    continue;
                }
                switch (dataType) {
                    case "string":
                    case "memo":
                        if (!valueField) {
                            obj[fieldName] = null;
                            break;
                        };
                        obj[fieldName] = valueField.toString();
                        break;

                    case "boolean":
                        obj[fieldName] = el.checked;
                        break;

                    case "integer":
                    case "bigint":
                    case "decimal":
                    case "double":
                    case "money":
                    case "picklist":
                    case "state":
                    case "status":
                        if (!valueField) {
                            obj[fieldName] = null;
                            break;
                        };
                        obj[fieldName] = parseFloat(valueField.toString());
                        break;

                    case "datetime":
                        if (!valueField) {
                            obj[fieldName] = null;
                            break;
                        };
                        obj[fieldName] = new Date(valueField.toString());
                        break;

                    case "lookup":
                    case "customer":
                    case "owner":
                        if (!valueField) {
                            obj[fieldName] = null;
                            break;
                        };
                        const attr = await _extensionSDK.getMetadataField(entityName, fieldName);
                        const entityNameField = attr.Targets?.[0];
                        const metadata = await top.Xrm.Utility.getEntityMetadata(entityNameField);
                        const entitySetName = metadata.EntitySetName;
                        obj[`${fieldName}@odata.bind`] = `/${entitySetName}(${valueField})`;
                        break;
                }
            }
            return obj;
        },

        /**
            * @property {string} viewId
         */
        getConfigView: async function (viewId) {
            const viewRecord = await BiSDK.WebApi.retrieveRecord("savedquery", viewId, ["name", "layoutxml", "returnedtypecode", "fetchxml"]);
            const mainEntityName = viewRecord.returnedtypecode;
            const clientUrl = top.Xrm.Utility.getGlobalContext().getClientUrl();

            const parser = new DOMParser();
            const layoutXmlDoc = parser.parseFromString(viewRecord.layoutxml, "text/xml");
            const fetchXmlDoc = parser.parseFromString(viewRecord.fetchxml, "text/xml");

            const aliasEntityMap = new Map();
            fetchXmlDoc.querySelectorAll("link-entity").forEach(linkEntity => {
                const alias = linkEntity.getAttribute("alias");
                const entityName = linkEntity.getAttribute("name");

                if (alias && entityName) {
                    aliasEntityMap.set(alias, entityName);
                }
            });

            const cells = [...layoutXmlDoc.querySelectorAll("cell")];
            const columns = cells.map(cell => {
                const cellName = cell.getAttribute("name") || "";

                let entityName = mainEntityName;
                let logicalName = cellName;
                let alias = null;
                let isRelated = false;

                const dotIndex = cellName.lastIndexOf(".");

                if (dotIndex > -1) {
                    alias = cellName.substring(0, dotIndex);

                    const relatedEntityName = aliasEntityMap.get(alias);
                    if (relatedEntityName) {
                        entityName = relatedEntityName;
                        logicalName = cellName.substring(dotIndex + 1);
                        isRelated = true;
                    }
                }

                return {
                    cell,
                    alias,
                    entityName,
                    logicalName,
                    isRelated
                };
            });

            const entityNames = [...new Set(columns.map(x => x.entityName))];

            const metadataResults = await Promise.all(
                entityNames.map(async (entityName) => {
                    const metadataUrl =
                        `${clientUrl}` +
                        `/api/data/v9.2/EntityDefinitions(LogicalName='${entityName}')` +
                        `?$select=LogicalName,DisplayName` +
                        `&$expand=Attributes($select=LogicalName,DisplayName)`;

                    const response = await fetch(metadataUrl, {
                        headers: {
                            "OData-MaxVersion": "4.0",
                            "OData-Version": "4.0",
                            "Accept": "application/json",
                            "Content-Type": "application/json"
                        }
                    });

                    const metadata = await response.json();

                    return {
                        entityName,
                        entityDisplayName:
                            metadata?.DisplayName?.UserLocalizedLabel?.Label ||
                            metadata?.DisplayName?.LocalizedLabels?.[0]?.Label ||
                            entityName,
                        attributes: metadata.Attributes || []
                    };
                })
            );

            const metadataMap = new Map(metadataResults.map(item => [item.entityName, item]));

            return columns.map(column => {
                const { cell, alias, entityName, logicalName, isRelated } = column;

                const entityMetadata = metadataMap.get(entityName);

                const attr = entityMetadata?.attributes?.find(x => x.LogicalName === logicalName);

                const columnDisplayName = attr?.DisplayName?.UserLocalizedLabel?.Label ||
                    attr?.DisplayName?.LocalizedLabels?.[0]?.Label ||
                    logicalName;

                const entityDisplayName = entityMetadata?.entityDisplayName || entityName;

                return {
                    logicalName,
                    alias,
                    entityName,
                    entityDisplayName,
                    isRelated,
                    width: Number(cell.getAttribute("width") || 100),
                    displayName: isRelated ? `${columnDisplayName} (${entityDisplayName})` : columnDisplayName,
                    fetchXml: viewRecord.fetchxml
                };
            });
        },

        addFilterParent: function (fetchXml, nameParent, idParent) {
            var parser = new DOMParser();
            var xmlDoc = parser.parseFromString(fetchXml, "text/xml");

            var filterNode = xmlDoc.getElementsByTagName("filter")[0];

            if (filterNode) {
                var newCondition = xmlDoc.createElement("condition");
                newCondition.setAttribute("attribute", nameParent);
                newCondition.setAttribute("operator", "eq");
                newCondition.setAttribute("value", `${idParent}`);
                filterNode.appendChild(newCondition);
            }

            var serializer = new XMLSerializer();
            var modifiedFetchXml = serializer.serializeToString(xmlDoc);
            return modifiedFetchXml;
        },
    },

    /**
        * @param {string} gridName
    */
    Grid: function (gridName) {
        if (!gridName) {
            throw new Error("gridName is required");
        }

        top.__BiSDKGridCache ??= {};
        top.__BiSDKGridCache[gridName] ??= {
            isLoaded: false,
            isExecuting: false,
            handlers: new Map(),
            waitingResolvers: []
        };

        const cache = top.__BiSDKGridCache[gridName];

        const executeCachedHandlers = async () => {
            if (cache.isExecuting) return;
            cache.isExecuting = true;

            try {
                for (const [key, handler] of cache.handlers) {
                    try {
                        await handler(true);
                    }
                    catch (error) {
                        console.error(`BiSDK.Grid("${gridName}") handler "${key}" error:`, error);
                    }
                }
            }
            finally {
                cache.isExecuting = false;
            }
        };

        return {
            Parent: new _extensionSDK.coreGrid(gridName, "parent"),
            Child: new _extensionSDK.coreGrid(gridName, "child"),

            /**
             *
             * @param {Function} loaded
             * @param {string} key
             * @returns {Promise<string>}
             */
            Loaded: function (loaded, key = gridName) {
                if (typeof loaded !== "function") return Promise.reject(new Error("Loaded callback must be a function"));

                cache.handlers.set(key, loaded);

                if (cache.isLoaded && top[gridName]) {
                    return Promise.resolve()
                        .then(() => loaded(true))
                        .then(() => "Grid Loaded!");
                }

                return new Promise((resolve) => {
                    cache.waitingResolvers.push(resolve);
                });
            },

            GridLoading: function () {
                cache.isLoaded = false;
                top[gridName] = false;
            },

            GridLoaded: async function () {
                cache.isLoaded = true;
                top[gridName] = true;

                BiSDK.UI.Loading.hide();

                await executeCachedHandlers();

                const resolvers = cache.waitingResolvers.splice(0);

                resolvers.forEach(resolve => {
                    resolve("Grid Loaded!");
                });

                return "Grid Loaded!";
            },

            Rebind: async function () {
                if (!cache.isLoaded) {
                    return false;
                }

                await executeCachedHandlers();

                return true;
            },

            RemoveLoaded: function (key = gridName) {
                return cache.handlers.delete(key);
            },

            ClearLoaded: function () {
                cache.handlers.clear();
                cache.waitingResolvers.length = 0;
            },

            GetLoadedHandlers: function () {
                return [...cache.handlers.keys()];
            },

            Button: {
                New: {
                    show: function () {
                        const button = document.getElementsByClassName(`button-grid-new-${gridName}`)[0];
                        if (button) {
                            button.style.display = "flex";
                        }
                        top[`button-grid-new-${gridName}`] = true;
                    },

                    hide: function () {
                        const button = document.getElementsByClassName(`button-grid-new-${gridName}`)[0];
                        if (button) {
                            button.style.display = "none";
                        }
                        top[`button-grid-new-${gridName}`] = false;
                    }
                },

                Delete: {
                    show: function () {
                        const button = document.getElementsByClassName(`button-grid-delete-${gridName}`)[0];
                        if (button && top["arrSelected"]?.size > 0) {
                            button.style.display = "flex";
                        }
                        top[`button-grid-delete-${gridName}`] = true;
                    },

                    hide: function () {
                        const button = document.getElementsByClassName(`button-grid-delete-${gridName}`)[0];
                        if (button) {
                            button.style.display = "none";
                        }
                        top[`button-grid-delete-${gridName}`] = false;
                    }
                },

                Deactivate: {
                    show: function () {
                        const button = document.getElementsByClassName(`button-grid-deactivate-${gridName}`)[0];
                        if (button && top["arrSelected"]?.size > 0) {
                            button.style.display = "flex";
                        }
                        top[`button-grid-deactivate-${gridName}`] = true;
                    },

                    hide: function () {
                        const button = document.getElementsByClassName(`button-grid-deactivate-${gridName}`)[0];
                        if (button) {
                            button.style.display = "none";
                        }
                        top[`button-grid-deactivate-${gridName}`] = false;
                    }
                },

                Save: {
                    show: function () {
                        const button = document.getElementsByClassName(`button-grid-save-${gridName}`)[0];
                        if (button) {
                            button.style.display = "flex";
                        }
                        top[`button-grid-save-${gridName}`] = true;
                    },

                    hide: function () {
                        const button = document.getElementsByClassName(`button-grid-save-${gridName}`)[0];
                        if (button) {
                            button.style.display = "none";
                        }
                        top[`button-grid-save-${gridName}`] = false;
                    }
                },

                /**
                 * @param {string} buttonName
                 * @param {Function} onClick
                 */
                Add: function ({ buttonName = "", onClick = async () => { } } = {}) {
                    function toSlug(str) {
                        return str
                            .toLowerCase()
                            .normalize('NFD')
                            .replace(/[\u0300-\u036f]/g, '')
                            .replace(/đ/g, 'd')
                            .replace(/[^a-zA-Z0-9\s]/g, '')
                            .trim()
                            .replace(/\s+/g, '-');
                    }
                    const id = `button-grid-${toSlug(buttonName)}`;
                    const html = `<div id="${id}" class="flex-center-center button-grid">
                                        <span class="mgr5">
                                            <i class="bi bi-text-center"></i>
                                        </span>
                                        <div class="mgl5">${buttonName}</div>
                                    </div>`;
                    document.getElementById("command-button-grid").insertAdjacentHTML("beforeend", html);
                    document.getElementById(id).onclick = async () => {
                        await onClick();
                    }
                }
            },

            setDisabledAll: async () => {
                const elParent = document.getElementsByClassName("parent-row");
                const elChild = document.getElementsByClassName("child-row");
                for (const el of elParent) {
                    const elFields = el.querySelectorAll(`[data-field]`);
                    for (const elField of elFields) {
                        const attribute = elField.getAttribute("data-field");
                        const elRecord = _extensionSDK.findDataRecord(elField, "parent");
                        const record = JSON.parse(elRecord.getAttribute(`data-record-parent`));
                        const elOverField = _extensionSDK.findElementField(elField, "parent");
                        const entityName = elField.getAttribute("data-entityName");
                        const alias = elField.getAttribute("data-alias");
                        elOverField.innerHTML = "";

                        let html = await BiSDK.UI.FillFieldData(record, attribute, entityName, alias, false);
                        elOverField.insertAdjacentHTML("beforeend", html);
                    }
                }
                for (const el of elChild) {
                    const elFields = el.querySelectorAll(`[data-field]`);
                    for (const elField of elFields) {
                        const attribute = elField.getAttribute("data-field");
                        const elRecord = _extensionSDK.findDataRecord(elField, "child");
                        const record = JSON.parse(elRecord.getAttribute(`data-record-child`));
                        const elOverField = _extensionSDK.findElementField(elField, "child");
                        const entityName = elField.getAttribute("data-entityName");
                        const alias = elField.getAttribute("data-alias");
                        elOverField.innerHTML = "";

                        let html = await BiSDK.UI.FillFieldData(record, attribute, entityName, alias, false);
                        elOverField.insertAdjacentHTML("beforeend", html);
                    }
                }
                return;
            },

            getSelectedRecords: function () {
                const selectedRecords = [];
                const arrSelected = top["arrSelected"];
                if (arrSelected && arrSelected.size > 0) {
                    for (const [id, entityName] of arrSelected.entries()) {
                        selectedRecords.push({ id, entityName });
                    }
                }
                return selectedRecords;
            }
        };
    },
};

window.BiSDK = BiSDK;
top.window.BiSDK = BiSDK;