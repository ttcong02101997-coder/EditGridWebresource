/// <reference path="./BiSDK.js" />
const formContext = top.Xrm.Page;
const idTarget = formContext.data.entity.getId().replace(/[{}]/g, "");
const mainGridContainer = document.querySelector(`[data-grid="mainGridContainer"]`);
var viewParent = null;
var viewChild = null;
var configParam = {};
var codeConfig = "";
var arrSelected = new Map();
var grid = null;

window.onload = async () => {
    BiSDK.UI.Loading.show("Vui lòng chờ trong giây lát...");
    await getConfigWeb();
    viewParent = await getSubgridViewInfo();
    if (configParam["ctt_haschild"]) {
        viewChild = await getSubgridDetail();
    }
    renderHeader();
    BiSDK.UI.Loading.hide();
    await onLoadPage();
    bindFunctionEvent();
}

const getConfigWeb = async () => {
    codeConfig = new URLSearchParams(window.location.search).get("data");
    if (!codeConfig) {
        BiSDK.UI.ShowAlert("Vui lòng config param webresource!", "error", "Thông báo");
        BiSDK.UI.Loading.hide();
        return;
    }
    mainGridContainer.setAttribute("data-id", `mainGrid-${codeConfig}`);

    grid = BiSDK.Grid(codeConfig);
    grid.GridLoading();
    try {
        const rs = await callCustomApi("GetConfigGrid", codeConfig);
        const configData = JSON.parse(rs.Result);
        configParam["ctt_entityname"] = configData["ctt_entityname"];
        configParam["ctt_entitynamechild"] = configData["ctt_entitynamechild"];
        configParam["ctt_haschild"] = configData["ctt_haschild"];
        configParam["ctt_parentlogicalname"] = configData["ctt_parentlogicalname"];
        configParam["ctt_listdieldeditchild"] = configData["ctt_listdieldeditchild"] && configData["ctt_listdieldeditchild"] != "" ? configData["ctt_listdieldeditchild"].split(",") : [];
        configParam["ctt_listfieldedit"] = configData["ctt_listfieldedit"] && configData["ctt_listfieldedit"] != "" ? configData["ctt_listfieldedit"].split(",") : [];
        configParam["ctt_parentlogicalnamefield"] = configData["ctt_parentlogicalnamefield"];
        configParam["ctt_viewid"] = configData["ctt_viewid"];
        configParam["ctt_viewidchild"] = configData["ctt_viewidchild"];
        document.getElementById("label-grid").innerText = configData["ctt_labelgrid"] || "";
    } catch (error) {
        BiSDK.UI.ShowAlert("Vui lòng config Edit Grid Configuration!", "error", "Thông báo");
        BiSDK.UI.Loading.hide();
        return;
    }
}

async function callCustomApi(actionName, data, recordId) {
    const request = {
        ActionName: actionName,
        Data: typeof data === "string" ? data : JSON.stringify(data),
        RecordID: recordId ? recordId : "",

        getMetadata: function () {
            return {
                boundParameter: null,
                operationType: 0,
                operationName: "ctt_ActionHandle",

                parameterTypes: {
                    ActionName: {
                        typeName: "Edm.String",
                        structuralProperty: 1
                    },
                    Data: {
                        typeName: "Edm.String",
                        structuralProperty: 1
                    },
                    RecordID: {
                        typeName: "Edm.String",
                        structuralProperty: 1
                    }
                }
            };
        }
    };

    const response = await top.Xrm.WebApi.online.execute(request);

    if (!response.ok) {
        throw new Error(await response.text());
    }

    return response.json();
}

async function getSubgridViewInfo() {
    const viewId = configParam["ctt_viewid"];
    return BiSDK.Utils.getConfigView(viewId);
}

async function getSubgridDetail() {
    const viewId = configParam["ctt_viewidchild"];
    return BiSDK.Utils.getConfigView(viewId);
}

const renderHeader = () => {
    let totalWitdh = 0;
    let widthBody = document.body.clientWidth;
    let wParent = 0;
    viewParent.forEach(v => { wParent += (v.width + 10) })
    if (viewChild) {
        let wChild = 0;
        viewChild.forEach(v => { wChild += (v.width + 10) })
        totalWitdh = wParent > wChild ? wParent : wChild;
    }
    else {
        totalWitdh = wParent;
    }
    if (totalWitdh > widthBody)
        mainGridContainer.style.width = totalWitdh + 240 + "px";
    else {
        if (widthBody - totalWitdh < 240) {
            mainGridContainer.style.width = "calc(100% + 240px)";
        }
        else {
            mainGridContainer.style.width = "100";
        }
    }

    let html = `<div style="display:flex;align-items: center;"> 
                    <div style="padding: 5px 5px 5px 17px;">
                        <input class="form-check-input" type="checkbox" id="checkbox-all"
                            style="width: 16px;
                                height: 15px;
                                cursor: pointer;">
                    </div>
                    <div style="width: 40px;"></div>`;
    viewParent.forEach((column, index) => {
        html += `   <div class="header-label1 fw-bold header-grid"
                        style='
                            width: ${column.width}px;
                            margin:0 5px;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            white-space: nowrap;
                            border: 2px solid white;
                        '
                        title="${column.displayName}"
                    >
                        ${column.displayName}
                    </div>`;
    });
    html += `</div>
            <div style="display: flex;justify-content: flex-end;">
                <div class="header-label1 fw-bold header-grid" style='width: 100px;margin:0 5px;border: 2px solid white;'>Thao tác</div>
            <div>`;
    document.getElementById("headerRow").insertAdjacentHTML("beforeend", html);
}

const onLoadPage = async () => {
    BiSDK.UI.Loading.show("Vui lòng chờ trong giây lát...");
    await genderUI();
    await grid.GridLoaded();
}

const genderUI = async () => {
    document.getElementById("mainContent").innerHTML = "";
    const dataParent = await getDataParent();
    if (dataParent.entities.length > 0) {
        for (const record of dataParent.entities) {
            let dataChild = null;
            if (configParam["ctt_haschild"])
                dataChild = await getDataDetail(record[`${configParam["ctt_entityname"]}id`]);
            //render data parent
            let html = `<div class="parent-group">
                            <div class="g-0 p-3 align-items-center parent-row hover-bg" style="display: flex;justify-content: space-between;padding-top: 10px !important;padding-bottom: 10px !important;" data-id="${codeConfig}-parent" ondblclick="navigateToRecord('${configParam["ctt_entityname"]}','${record[`${configParam["ctt_entityname"]}id`]}')">
                                <div style="display: flex;align-items: center;">
                                    <div style="padding: 5px 15px 5px 5px;">
                                        <input class="form-check-input check-box-row parent" data-entityname="${configParam["ctt_entityname"]}" type="checkbox" id="${record[`${configParam["ctt_entityname"]}id`]}"
                                        style="width: 16px;
                                            height: 15px;
                                            cursor: pointer;"
                                        >
                                    </div>
                                    <div data-record-parent='${JSON.stringify(record)}' style="display:none" class="has-record"></div>
                                    <div class="align-items-center" style="width: 40px;opacity:${configParam["ctt_haschild"] && dataChild.entities.length > 0 ? "1" : "0"}" onclick="toggleDetail('detail-${record[`${configParam["ctt_entityname"]}id`]}', this)">
                                        <i class="bi bi-chevron-right chevron-icon rotate me-3"></i>
                                    </div>`;
            for (const column of viewParent) {
                let htmlField = "";
                if (configParam["ctt_listfieldedit"].includes(column.logicalName)) {
                    htmlField = await BiSDK.UI.FillFieldDataEdit(record, column.logicalName, column.entityName, column.alias, column.isRelated);
                }
                else {
                    htmlField = await BiSDK.UI.FillFieldData(record, column.logicalName, column.entityName, column.alias, column.isRelated);
                }
                html += `    <div class="text-dark parent-field" style="width: ${column.width}px;margin:0 5px;">
                                ${htmlField}
                            </div>`;
            }
            html += `           </div>`;
            if (configParam["ctt_listfieldedit"].length > 0) {
                html += `       <div class="fw-medium" style="width:100px;display:flex;align-items: center;justify-content: flex-end;">
                                    <div data-idbutton-save="button-grid-save-${codeConfig}" class="action-tion" style="display: inline-block;
                                        padding: 5px 10px;
                                        cursor: pointer;
                                        border-radius: 5px;
                                        margin:0 5px;
                                        "
                                        onclick="saveParentRecord('${record[`${configParam["ctt_entityname"]}id`]}',this)"
                                    >
                                        <i class="bi bi-floppy"></i>
                                    </div>
                                    <div class="action-tion" style="display: inline-block;
                                        padding: 5px 10px;
                                        cursor: pointer;
                                        border-radius: 5px;
                                        margin:0 5px;
                                        "
                                        onclick="openViewRecord('${configParam["ctt_entityname"]}','${record[`${configParam["ctt_entityname"]}id`]}')"
                                        >
                                            <i class="bi bi-eye"></i>
                                    </div>
                                </div>`;
            }
            else {
                html += `       <div class="fw-medium" style="width:100px;display: flex;align-items: center;justify-content: flex-end;">
                                    <div class="action-tion" style="display: inline-block;
                                        padding: 5px 10px;
                                        cursor: pointer;
                                        border-radius: 5px;
                                        margin:0 5px;
                                        "
                                        onclick="openViewRecord('${configParam["ctt_entityname"]}','${record[`${configParam["ctt_entityname"]}id`]}')"
                                    >
                                        <i class="bi bi-eye"></i>
                                    </div>
                                </div>`;
            }
            html += `       </div>`;
            if (configParam["ctt_haschild"]) {
                dataChild = await getDataDetail(record[`${configParam["ctt_entityname"]}id`]);
                if (dataChild.entities.length > 0) {
                    //render header child
                    html += `<div class="collapse show" id="detail-${record[`${configParam["ctt_entityname"]}id`]}">
                            <div class="sub-grid-container py-3 border-top border-left-indicator">
                                <div class="g-0 mb-1 border-bottom header-label" style="flex-wrap: unset;margin-left: 90px;align-items: center;display: flex;justify-content: space-between;" >
                                    <div style="padding: 5px 5px 5px 17px;">
                                        <input class="form-check-input" type="checkbox" id="checkbox-all-child"
                                            style="width: 16px;
                                                height: 15px;
                                                cursor: pointer;">
                                    </div>  
                                    <div style="display:flex;alight-item:center;">`;
                    for (const column of viewChild) {
                        html += `       <div class="px-3 py-2 header-grid"
                                            style="
                                                width: ${column.width}px;
                                                margin:0 5px;
                                                overflow: hidden;
                                                text-overflow: ellipsis;
                                                border: 2px solid white;
                                                white-space: nowrap;" title="${column.displayName}
                                            "
                                        >
                                                ${column.displayName}
                                        </div>`;
                    }
                    html += `       </div>
                                    <div style="display: flex;justify-content: flex-end;">
                                        <div class="px-3 py-2 header-grid" style="width:100px;margin:0 5px;border: 2px solid white;">Thao tác</div>
                                    </div>
                                </div>`;
                    //render data child
                    for (const subRecord of dataChild.entities) {
                        html += `<div class="g-0 px-3 py-2 mx-5 align-items-center child-row border-bottom" style="margin-left: 90px !important;align-items: center;display: flex;justify-content: space-between;margin-right:0 !important" data-id="${codeConfig}-child" ondblclick="navigateToRecord('${configParam["ctt_entitynamechild"]}','${subRecord[`${configParam["ctt_entitynamechild"]}id`]}')">
                                <div data-record-child='${JSON.stringify(subRecord)}' style="display:none" class="has-record"></div>
                                 <div style="padding: 5px 15px 5px 5px;">
                                        <input class="form-check-input check-box-row child" data-entityName="${configParam["ctt_entitynamechild"]}" type="checkbox" id="${subRecord[`${configParam["ctt_entitynamechild"]}id`]}"
                                        style="width: 16px;
                                            height: 15px;
                                            cursor: pointer;"
                                        >
                                    </div>   
                                <div style="display:flex;alight-item:center;">`;
                        for (const column of viewChild) {
                            let htmlField = "";
                            if (configParam["ctt_listdieldeditchild"].includes(column.logicalName)) {
                                htmlField = await BiSDK.UI.FillFieldDataEdit(subRecord, column.logicalName, column.entityName, column.alias, column.isRelated);
                            }
                            else {
                                htmlField = await BiSDK.UI.FillFieldData(subRecord, column.logicalName, column.entityName, column.alias, column.isRelated);
                            }
                            html += `<div class="fw-medium child-field" style="width: ${column.width}px;margin:0 5px;">
                                    ${htmlField}
                                </div>`;
                        }
                        html += `</div>
                                    <div style="display: flex;justify-content: flex-end;">`;
                        if (configParam["ctt_listdieldeditchild"].length > 0) {
                            html += `<div class="fw-medium" style="width:100px;display:flex;align-items: center;justify-content: flex-end;">
                                        <div data-idbutton-save="button-grid-save-${codeConfig}" class="action-tion" style="display: inline-block;
                                            padding: 5px 10px;
                                            cursor: pointer;
                                            border-radius: 5px;
                                            margin:0 5px;
                                            "
                                            onclick="saveChildRecord('${subRecord[`${configParam["ctt_entitynamechild"]}id`]}',this)"
                                        >
                                            <i class="bi bi-floppy"></i>
                                        </div>
                                        <div class="action-tion" style="display: inline-block;
                                            padding: 5px 10px;
                                            cursor: pointer;
                                            border-radius: 5px;
                                            margin:0 5px;
                                            "
                                            onclick="openViewRecord('${configParam["ctt_entitynamechild"]}','${subRecord[`${configParam["ctt_entitynamechild"]}id`]}')"
                                            >
                                                <i class="bi bi-eye"></i>
                                        </div>
                                    </div>`;
                        }
                        else {
                            html += `<div class="fw-medium" style="width:100px;display: flex;justify-content: flex-end;">
                                        <div class="action-tion" style="display: inline-block;
                                            padding: 5px 10px;
                                            cursor: pointer;
                                            border-radius: 5px;
                                            margin:0 5px;
                                            "
                                            onclick="openViewRecord('${configParam["ctt_entitynamechild"]}','${subRecord[`${configParam["ctt_entitynamechild"]}id`]}')"
                                            >
                                                <i class="bi bi-eye"></i>
                                        </div>
                                    </div>`;
                        }
                        html += `</div></div>`;
                    }
                    html += `</div>
                    </div>`;
                }
            }
            html += `</div>`;

            document.getElementById("mainContent").insertAdjacentHTML("beforeend", html);
        }
    }
    else {
        let html = `<div class="g-0 p-3 align-items-center parent-row hover-bg" style="flex-wrap:unset;text-align: center;">
                        Không có dữ liệu để hiển thị
                    </div>`;
        document.getElementById("mainContent").insertAdjacentHTML("beforeend", html);
        for (let index = 0; index < document.getElementsByClassName("button-grid").length; index++) {
            const element = document.getElementsByClassName("button-grid")[index];
            element.style.display = "none";
        }
    }

    for (let index = 0; index < document.getElementsByClassName("header-grid").length; index++) {
        const element = document.getElementsByClassName("header-grid")[index];
        element.addEventListener("mouseenter", () => {
            element.style.borderColor = "rgb(15, 108, 189)";
        });

        element.addEventListener("mouseleave", () => {
            element.style.borderColor = "white";
        });
    }

    for (let index = 0; index < document.getElementsByClassName("action-tion").length; index++) {
        const element = document.getElementsByClassName("action-tion")[index];
        element.addEventListener("mouseenter", () => {
            element.style.background = "#cccccc";
        });

        element.addEventListener("mouseleave", () => {
            element.style.background = "transparent";
        });
    }

    BiSDK.UI.Loading.hide();
    BiSDK.Grid(codeConfig).GridLoaded();
    return;
}

const navigateToRecord = (entityName, id) => {
    top.Xrm.Navigation.navigateTo({
        pageType: "entityrecord",
        entityName: entityName,
        entityId: id
    });
}

const bindFunctionEvent = () => {
    const entityName = configParam["ctt_entityname"];
    const buttonNew = document.getElementById("button-grid-new");
    const buttonSave = document.getElementById("button-grid-save");
    const buttonDelete = document.getElementById("button-grid-delete");
    const buttonDeactivate = document.getElementById("button-grid-deactivate");
    const buttonRefresh = document.getElementById("button-grid-refresh");

    buttonNew.classList.add(`button-grid-new-${codeConfig}`);
    top[`button-grid-new-${codeConfig}`] = true;
    buttonNew.addEventListener("click", async () => {
        let _data = {};
        _data[configParam["ctt_parentlogicalname"]] = idTarget;
        _data[configParam["ctt_parentlogicalname"] + "name"] = formContext.data.entity.getPrimaryAttributeValue();
        _data[configParam["ctt_parentlogicalname"] + "type"] = formContext.data.entity.getEntityName();

        const result = await top.Xrm.Navigation.navigateTo(
            {
                pageType: "entityrecord",
                entityName: entityName,
                data: _data
            },
            {
                target: 2
            }
        );
        const savedRecord = result?.savedEntityReference?.[0];
        if (!savedRecord?.id) {
            return;
        }

        onLoadPage();
    });

    buttonSave.classList.add(`button-grid-save-${codeConfig}`);
    top[`button-grid-save-${codeConfig}`] = true;
    buttonSave.addEventListener("click", saveAllRecord);

    buttonRefresh.classList.add(`button-grid-refresh-${codeConfig}`);
    buttonRefresh.addEventListener("click", () => {
        onLoadPage();
    });

    buttonDelete.classList.add(`button-grid-delete-${codeConfig}`);
    top[`button-grid-delete-${codeConfig}`] = true;
    buttonDelete.style.display = "none";
    buttonDelete.onclick = () => { handleClickDelete() };

    buttonDeactivate.classList.add(`button-grid-deactivate-${codeConfig}`);
    top[`button-grid-deactivate-${codeConfig}`] = true;
    buttonDeactivate.style.display = "none";
    buttonDeactivate.onclick = () => { handleClickDeactivate() };

    for (let item of document.getElementsByClassName("check-box-row")) {
        item.addEventListener("change", (e) => {
            if (e.target.checked) {
                const entityName = item.getAttribute("data-entityName");
                arrSelected.set(e.target.id, entityName);
            }
            else {
                arrSelected.delete(e.target.id);
                if (item.classList.value.indexOf("child") != -1)
                    document.getElementById("checkbox-all-child").checked = false;
                else
                    document.getElementById("checkbox-all").checked = false;
            }

            handleButtonDeleteAndDeactivate(buttonDelete, buttonDeactivate);
            top["arrSelected"] = arrSelected;
        })
    }

    document.getElementById("checkbox-all")?.addEventListener("change", (e) => {
        if (e.target.checked) {
            for (let item of document.getElementsByClassName("check-box-row")) {
                if (item.classList.value.indexOf("parent") != -1) {
                    const entityName = item.getAttribute("data-entityName");
                    item.checked = true;
                    arrSelected.set(item.id, entityName);
                }
            }
        }
        else {
            for (let item of document.getElementsByClassName("check-box-row")) {
                if (item.classList.value.indexOf("parent") != -1) {
                    item.checked = false;
                    arrSelected.delete(item.id);
                }
            }
        }

        handleButtonDeleteAndDeactivate(buttonDelete, buttonDeactivate);
        top["arrSelected"] = arrSelected;
    })

    document.getElementById("checkbox-all-child")?.addEventListener("change", (e) => {
        if (e.target.checked) {
            for (let item of document.getElementsByClassName("check-box-row")) {
                if (item.classList.value.indexOf("child") != -1) {
                    const entityName = item.getAttribute("data-entityName");
                    item.checked = true;
                    arrSelected.set(item.id, entityName);
                }
            }
        }
        else {
            for (let item of document.getElementsByClassName("check-box-row")) {
                if (item.classList.value.indexOf("child") != -1) {
                    item.checked = false;
                    arrSelected.delete(item.id);
                }
            }
        }

        handleButtonDeleteAndDeactivate(buttonDelete, buttonDeactivate);
        top["arrSelected"] = arrSelected;
    })
}

const handleButtonDeleteAndDeactivate = (buttonDelete, buttonDeactivate) => {
    if (arrSelected.size > 0 && top[`button-grid-delete-${codeConfig}`] == true) {
        buttonDelete.style.display = "flex";
    }
    else {
        buttonDelete.style.display = "none";
    }

    if (arrSelected.size > 0 && top[`button-grid-deactivate-${codeConfig}`] == true) {
        buttonDeactivate.style.display = "flex";
    }
    else {
        buttonDeactivate.style.display = "none";
    }
}

const saveAllRecord = async () => {
    try {
        BiSDK.UI.Loading.show("Vui lòng chờ...");
        const allInput = document.getElementsByClassName("check-box-row");

        await Promise.all(
            [...allInput].map(async (item) => {
                const entityName = item.getAttribute("data-entityName");
                const el = findElementFieldDataId(item);

                const objData = await BiSDK.Utils.GetDataFields(entityName, el);
                return BiSDK.WebApi.updateRecord(entityName, item.id, objData);
            })
        );

        BiSDK.UI.ShowAlert("Thành công", "success", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
    catch (error) {
        BiSDK.UI.ShowAlert(error.message, "error", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
}

const findElementFieldDataId = (element) => {
    if (!element) return null;

    if (element.querySelector(`[data-idbutton-save="button-grid-save-${codeConfig}"]`)) {
        return element.querySelector(`[data-idbutton-save="button-grid-save-${codeConfig}"]`);
    }

    return findElementFieldDataId(element.parentElement);
}

const handleClickDelete = () => {
    BiSDK.UI.Modal.show({
        title: "Xác nhận",
        content: "Bạn có chắc muốn xóa?",
        width: 300,
        saveCallback: async () => {
            BiSDK.UI.Loading.global.show();
            const promises = [];

            for (const id of arrSelected.keys()) {
                const entityName = arrSelected.get(id);
                promises.push(
                    BiSDK.WebApi.deleteRecord(entityName, id)
                );
            }

            await Promise.all(promises);

            BiSDK.UI.Loading.global.hide();
            onLoadPage();
        }
    })
}

const handleClickDeactivate = () => {
    BiSDK.UI.Modal.show({
        title: "Xác nhận",
        content: "Bạn có chắc muốn Deactivate?",
        width: 300,
        saveCallback: async () => {
            BiSDK.UI.Loading.global.show();
            const promises = [];
            let objectState = {
                "statecode": 1,
                "statuscode": 2
            };
            for (const id of arrSelected.keys()) {
                const entityName = arrSelected.get(id);
                promises.push(
                    BiSDK.WebApi.updateRecord(entityName, id, objectState)
                );
            }

            await Promise.all(promises);

            BiSDK.UI.Loading.global.hide();
            onLoadPage();
        }
    })
}

const saveParentRecord = async (id, element) => {
    try {
        BiSDK.UI.Loading.show("Vui lòng chờ...");
        const entityName = configParam["ctt_entityname"];
        const objData = await BiSDK.Utils.GetDataFields(entityName, element);
        await BiSDK.WebApi.updateRecord(entityName, id, objData);
        BiSDK.UI.ShowAlert("Thành công", "success", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
    catch (error) {
        BiSDK.UI.ShowAlert(error.message, "error", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
}

const saveChildRecord = async (id, element) => {
    try {
        BiSDK.UI.Loading.show("Vui lòng chờ...");
        const entityName = configParam["ctt_entitynamechild"];
        const objData = await BiSDK.Utils.GetDataFields(entityName, element);
        await BiSDK.WebApi.updateRecord(entityName, id, objData);
        BiSDK.UI.ShowAlert("Thành công", "success", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
    catch (error) {
        BiSDK.UI.ShowAlert(error.message, "error", "Thông báo");
        BiSDK.UI.Loading.hide();
    }
}

const getDataParent = async () => {
    const fetchXml = BiSDK.Utils.addFilterParent(viewParent[0].fetchXml, configParam["ctt_parentlogicalname"], idTarget);
    const dataKQSC = await BiSDK.WebApi.retrieveMultipleRecords(configParam["ctt_entityname"], fetchXml);
    return dataKQSC;
}

const getDataDetail = async (idParent) => {
    const fetchXml = BiSDK.Utils.addFilterParent(viewChild[0].fetchXml, configParam["ctt_parentlogicalnamefield"], idParent);
    return await BiSDK.WebApi.retrieveMultipleRecords(configParam["ctt_entitynamechild"], fetchXml);
}

const openViewRecord = (entityName, id) => {
    const url = top.Xrm.Utility.getGlobalContext().getClientUrl() + `/main.aspx?etn=${entityName}&pagetype=entityrecord&id=${id}`;
    window.open(url, "_blank");
}

function toggleDetail(id, element) {
    const target = document.getElementById(id);
    const icon = element.querySelector('.chevron-icon');
    const bsCollapse = new bootstrap.Collapse(target, { toggle: false });

    if (target.classList.contains('show')) {
        bsCollapse.hide();
        icon.classList.remove('rotate');
    } else {
        bsCollapse.show();
        icon.classList.add('rotate');
    }
}
