﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CTT.Xrm.ActionHandle
{
    public class Program : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(null);

            try
            {
                string ActionName = context.InputParameters.Contains("ActionName") ? context.InputParameters["ActionName"].ToString() : "";
                string Data = context.InputParameters.Contains("Data") ? context.InputParameters["Data"].ToString() : "";
                string RecordID = context.InputParameters.Contains("RecordID") ? context.InputParameters["RecordID"].ToString() : "";

                switch (ActionName)
                {
                    case "GetConfigGrid":
                        var results = GetConfigGrid(service, Data);
                        if (results.Entities.Count > 0)
                        {
                            var configData = results.Entities.FirstOrDefault();
                            var configParam = new Dictionary<string, object>
                            {
                                ["ctt_entityname"] = configData.GetAttributeValue<string>("ctt_entityname"),
                                ["ctt_entitynamechild"] = configData.GetAttributeValue<string>("ctt_entitynamechild"),
                                ["ctt_haschild"] = configData.GetAttributeValue<bool?>("ctt_haschild"),
                                ["ctt_parentlogicalname"] = configData.GetAttributeValue<string>("ctt_parentlogicalname"),
                                ["ctt_listdieldeditchild"] = configData.GetAttributeValue<string>("ctt_listdieldeditchild"),
                                ["ctt_listfieldedit"] = configData.GetAttributeValue<string>("ctt_listfieldedit"),
                                ["ctt_parentlogicalnamefield"] = configData.GetAttributeValue<string>("ctt_parentlogicalnamefield"),
                                ["ctt_viewid"] = configData.GetAttributeValue<string>("ctt_viewid"),
                                ["ctt_viewidchild"] = configData.GetAttributeValue<string>("ctt_viewidchild")
                            };

                            string json = JsonConvert.SerializeObject(configParam);
                            context.OutputParameters["Result"] = json;
                        }
                        else
                        {
                            throw new InvalidPluginExecutionException("Vui lòng config Edit Grid Configuration!");
                        }
                        break;
                    default:
                        throw new InvalidPluginExecutionException($"Unknown action: {ActionName}");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        private EntityCollection GetConfigGrid(IOrganizationService service, string Data)
        {
            var fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                    <fetch>
                      <entity name=""ctt_editgridconfiguration"">
                        <attribute name=""ctt_entityname"" />
                        <attribute name=""ctt_entitynamechild"" />
                        <attribute name=""ctt_haschild"" />
                        <attribute name=""ctt_parentlogicalname"" />
                        <attribute name=""ctt_listdieldeditchild"" />
                        <attribute name=""ctt_listfieldedit"" />
                        <attribute name=""ctt_parentlogicalnamefield"" />
                        <attribute name=""ctt_viewid"" />
                        <attribute name=""ctt_viewidchild"" />
                        <attribute name=""ctt_labelgrid"" />
                        <filter>
                          <condition attribute=""ctt_codeconfig"" operator=""eq"" value=""{Data}"" />
                        </filter>
                      </entity>
                    </fetch>";
            return service.RetrieveMultiple(new FetchExpression(fetchXml));
        }
    }
}
